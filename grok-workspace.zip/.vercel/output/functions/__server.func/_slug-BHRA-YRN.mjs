import { T as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as useSite } from "./_ssr/use-site-ChaMm9lO.mjs";
import { a as Route$3, k as EmptyState } from "./_ssr/router-wjzIUxJ1.mjs";
import { t as IndexList } from "./_ssr/index-list-C_IXj46n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-BHRA-YRN.js
var import_jsx_runtime = require_jsx_runtime();
function TopicPage() {
	const site = useSite();
	const { category, articles, meta } = Route$3.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.topicsKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: category.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: category.description
					})
				]
			}), articles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, {
				articles,
				meta,
				minRead: site.labels.minRead
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {})]
		})
	});
}
//#endregion
export { TopicPage as component };
