import { A as NotFoundState } from "./_ssr/router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-B5qmcP3Q.js
var SplitNotFoundComponent = NotFoundState;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
