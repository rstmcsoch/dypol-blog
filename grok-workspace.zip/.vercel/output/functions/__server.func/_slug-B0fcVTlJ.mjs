import { T as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as useSite } from "./_ssr/use-site-ChaMm9lO.mjs";
import { c as Route$7 } from "./_ssr/router-wjzIUxJ1.mjs";
import { t as ArticleView } from "./_ssr/article-view-CzJP606H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-B0fcVTlJ.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const site = useSite();
	const data = Route$7.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleView, {
		...data,
		site
	});
}
//#endregion
export { ArticlePage as component };
