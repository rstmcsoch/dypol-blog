import { A as NotFoundState } from "./_ssr/router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-ClwaIRTe.js
var SplitComponent = NotFoundState;
//#endregion
export { SplitComponent as component };
