import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useSite } from "./use-site-ChaMm9lO.mjs";
import { l as Route$8 } from "./router-wjzIUxJ1.mjs";
import { t as IndexList } from "./index-list-C_IXj46n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articles-DGQuQNJc.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlesPage() {
	const site = useSite();
	const { articles, meta } = Route$8.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.indexKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: site.labels.indexTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: site.labels.indexLede
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, {
				articles,
				meta,
				minRead: site.labels.minRead
			})]
		})
	});
}
//#endregion
export { ArticlesPage as component };
