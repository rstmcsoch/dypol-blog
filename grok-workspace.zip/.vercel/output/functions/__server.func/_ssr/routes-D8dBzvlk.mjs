import { S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useSite } from "./use-site-ChaMm9lO.mjs";
import { g as Route$19 } from "./router-wjzIUxJ1.mjs";
import { n as padIndex, t as formatDate } from "./format-BabHa5xU.mjs";
import { t as CoverPlate } from "./cover-plate-7EjIFUWy.mjs";
import { t as IndexList } from "./index-list-C_IXj46n.mjs";
import { t as TopicGrid } from "./topic-grid-B1ZyDRBA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D8dBzvlk.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const site = useSite();
	const { lead, band, index, meta, topics } = Route$19.useLoaderData();
	if (!lead) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: site.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lede",
				children: site.labels.emptyBody
			})]
		})
	});
	const leadMeta = meta[lead.id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "lead-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container lead-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lead-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "kicker",
							children: [site.labels.featured, leadMeta?.categoryLabel ? ` · ${leadMeta.categoryLabel}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/articles/$slug",
								params: { slug: lead.slug },
								children: lead.title
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lede",
							children: lead.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "meta",
							children: [lead.publishedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate(lead.publishedAt) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								leadMeta?.minutes ?? 1,
								" ",
								site.labels.minRead
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/articles/$slug",
							params: { slug: lead.slug },
							className: "btn",
							children: site.labels.read
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/articles/$slug",
					params: { slug: lead.slug },
					className: "plate-link",
					"aria-label": lead.title,
					children: lead.coverMediaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "article-cover",
						src: `/media/${lead.coverMediaId}`,
						alt: ""
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverPlate, {
						motif: lead.motif,
						index: padIndex(leadMeta?.rank ?? 1),
						category: leadMeta?.categoryLabel ?? ""
					})
				})]
			})
		}),
		band.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "band",
			"aria-labelledby": "also-filed",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grain-layer",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container band-inner",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "also-filed",
					className: "band-head",
					children: site.labels.also
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "band-grid",
					children: band.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/articles/$slug",
						params: { slug: article.slug },
						className: "band-link",
						children: [meta[article.id]?.categoryLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "band-link__cat",
							children: meta[article.id]?.categoryLabel
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "band-link__title",
							children: article.title
						})]
					}) }, article.id))
				})]
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			"aria-labelledby": "latest",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "latest",
						children: site.labels.latest
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/articles",
						className: "text-link",
						children: site.labels.fullIndex
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, {
					articles: index,
					meta,
					minRead: site.labels.minRead
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section section--flush",
			"aria-labelledby": "topics",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-head",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "topics",
						children: site.labels.topics
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicGrid, { topics })]
			})
		})
	] });
}
//#endregion
export { Home as component };
