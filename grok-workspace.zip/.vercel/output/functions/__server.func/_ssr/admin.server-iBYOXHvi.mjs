import { r as getSql } from "./db-BEOxeoR1.mjs";
import { UnauthorizedError, getSessionUser, requireUserId, t as authConfigured } from "./verify.server-Dg4HhVj9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.server-iBYOXHvi.js
var ForbiddenError = class extends Error {
	status = 403;
	constructor() {
		super("Forbidden");
		this.name = "ForbiddenError";
	}
};
function allowlist() {
	return (process.env.ADMIN_EMAILS ?? "").split(",").map((entry) => entry.trim().toLowerCase()).filter(Boolean);
}
/**
* Server-side desk check.
* Sign-in off (this workspace default) resolves the shared dev user.
* Sign-in on requires a session whose email is in ADMIN_EMAILS or admin_grants.
*/
async function requireAdmin(bearerToken) {
	const userId = await requireUserId(bearerToken);
	if (!authConfigured) return {
		id: userId,
		email: null,
		mode: "dev"
	};
	const user = await getSessionUser(bearerToken);
	if (!user) throw new UnauthorizedError();
	const email = user.email?.trim().toLowerCase() ?? "";
	const listed = allowlist();
	if (listed.length > 0) {
		if (!email || !listed.includes(email)) throw new ForbiddenError();
		return {
			id: user.id,
			email: user.email,
			mode: "account"
		};
	}
	const grants = await (await getSql())`select email from admin_grants`;
	if (!email || !grants.some((row) => row.email.toLowerCase() === email)) throw new ForbiddenError();
	return {
		id: user.id,
		email: user.email,
		mode: "account"
	};
}
async function listGrants() {
	return (await (await getSql())`select email from admin_grants order by email asc`).map((row) => row.email);
}
async function addGrant(email) {
	const normalized = email.trim().toLowerCase();
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) throw new Error("Enter a valid email.");
	await (await getSql())`insert into admin_grants (email) values (${normalized}) on conflict (email) do nothing`;
}
async function removeGrant(email) {
	await (await getSql())`delete from admin_grants where email = ${email.trim().toLowerCase()}`;
}
//#endregion
export { addGrant, listGrants, removeGrant, requireAdmin };
