//#region node_modules/.nitro/vite/services/ssr/assets/present-Dcl3727_.js
function readingMinutes(article) {
	const words = blockText(article.blocks).trim().split(/\s+/).filter(Boolean).length;
	return Math.max(1, Math.round(words / 220));
}
function blockText(blocks) {
	return blocks.map((block) => {
		if (block.type === "list") return block.items.join(" ");
		if (block.type === "code") return block.code;
		return block.text;
	}).join(" ");
}
//#endregion
export { readingMinutes as t };
