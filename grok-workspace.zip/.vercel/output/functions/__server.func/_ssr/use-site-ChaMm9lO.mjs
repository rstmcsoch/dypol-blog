import { n as site } from "./types-BLz7yWjW.mjs";
import { x as getRouteApi } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-site-ChaMm9lO.js
var rootRoute = getRouteApi("__root__");
function useSite() {
	return rootRoute.useLoaderData()?.site ?? site;
}
function useTrending() {
	return rootRoute.useLoaderData()?.trending ?? [];
}
//#endregion
export { useTrending as n, useSite as t };
