import { o as __toESM } from "../_runtime.mjs";
import { T as require_jsx_runtime, et as require_react, w as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as adminRemoveGrant, E as adminSaveSettings, _ as errorText, d as Route$10, v as adminAddGrant } from "./router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BO2roKeW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsDesk() {
	const data = Route$10.useLoaderData();
	const router = useRouter();
	const [site, setSite] = (0, import_react.useState)(data.site);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [grant, setGrant] = (0, import_react.useState)("");
	function patch(next) {
		setSite((current) => ({
			...current,
			...next
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-kicker",
			children: "Configuration"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "desk-title",
			children: "Settings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: data.mode === "dev" ? "Sign-in is off in this environment, so the desk is open to this preview. When sign-in is on, only emails in ADMIN_EMAILS or the grant list can publish." : `Signed in as ${data.email ?? "an editor"}.`
		}),
		data.mediaNotice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner banner--bad",
			role: "alert",
			children: data.mediaNotice
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner banner--bad",
			role: "alert",
			children: error
		}) : null,
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner",
			role: "status",
			children: message
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "stack",
			style: { marginTop: "1rem" },
			onSubmit: (event) => {
				event.preventDefault();
				setPending(true);
				setError(null);
				adminSaveSettings({ data: site }).then(async () => {
					setMessage("Settings saved.");
					await router.invalidate();
				}).catch((caught) => setError(errorText(caught))).finally(() => setPending(false));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Website name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: site.name,
						onChange: (event) => patch({ name: event.target.value }),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Site title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: site.title,
						onChange: (event) => patch({ title: event.target.value }),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: site.description,
						onChange: (event) => patch({ description: event.target.value }),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Publisher" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: site.publisher,
						onChange: (event) => patch({ publisher: event.target.value }),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Logo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: site.logoMediaId ?? "",
						onChange: (event) => patch({ logoMediaId: event.target.value || null }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Wordmark only"
						}), data.media.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.filename
						}, item.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Favicon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: site.faviconMediaId ?? "",
						onChange: (event) => patch({ faviconMediaId: event.target.value || null }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Default mark"
						}), data.media.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.filename
						}, item.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "block-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { children: "Navigation" }), site.nav.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "filters",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.href }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: item.label,
									onChange: (event) => {
										patch({ nav: site.nav.map((entry, entryIndex) => entryIndex === index ? {
											...entry,
											label: event.target.value
										} : entry) });
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "check-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: item.visible,
									onChange: (event) => {
										patch({ nav: site.nav.map((entry, entryIndex) => entryIndex === index ? {
											...entry,
											visible: event.target.checked
										} : entry) });
									}
								}), "Visible"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn--ghost",
								onClick: () => {
									if (index === 0) return;
									const nav = [...site.nav];
									const [moved] = nav.splice(index, 1);
									if (!moved) return;
									nav.splice(index - 1, 0, moved);
									patch({ nav });
								},
								children: "Up"
							})
						]
					}, item.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "block-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { children: "Now bar" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "check-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: site.trending.enabled,
								onChange: (event) => patch({ trending: {
									...site.trending,
									enabled: event.target.checked
								} })
							}), "Enabled"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Label" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: site.trending.label,
								onChange: (event) => patch({ trending: {
									...site.trending,
									label: event.target.value
								} })
							})]
						}),
						data.articles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "check-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: site.trending.slugs.includes(article.slug),
								onChange: (event) => {
									const slugs = event.target.checked ? [...site.trending.slugs, article.slug] : site.trending.slugs.filter((slug) => slug !== article.slug);
									patch({ trending: {
										...site.trending,
										slugs
									} });
								}
							}), article.title]
						}, article.slug))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Footer note" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: site.footer.note,
						onChange: (event) => patch({ footer: {
							...site.footer,
							note: event.target.value
						} })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "block-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { children: "Footer links" }),
						site.footer.links.map((link, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "filters",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Label" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: link.label,
										onChange: (event) => {
											const links = site.footer.links.map((entry, entryIndex) => entryIndex === index ? {
												...entry,
												label: event.target.value
											} : entry);
											patch({ footer: {
												...site.footer,
												links
											} });
										}
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "URL" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: link.href,
										onChange: (event) => {
											const links = site.footer.links.map((entry, entryIndex) => entryIndex === index ? {
												...entry,
												href: event.target.value
											} : entry);
											patch({ footer: {
												...site.footer,
												links
											} });
										}
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn--ghost",
									onClick: () => patch({ footer: {
										...site.footer,
										links: site.footer.links.filter((_, i) => i !== index)
									} }),
									children: "Remove"
								})
							]
						}, link.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn--ghost",
							onClick: () => patch({ footer: {
								...site.footer,
								links: [...site.footer.links, {
									id: `link-${Date.now()}`,
									label: "Link",
									href: "/"
								}]
							} }),
							children: "Add link"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "About, one paragraph per block. Separate paragraphs with a blank line." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: site.about.paragraphs.join("\n\n"),
						onChange: (event) => patch({ about: { paragraphs: event.target.value.split(/\n\s*\n/).map((paragraph) => paragraph.trim()).filter(Boolean) } })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "block-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Presentation labels" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "stack",
						children: Object.keys(site.labels).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: key }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: site.labels[key],
								onChange: (event) => patch({ labels: {
									...site.labels,
									[key]: event.target.value
								} })
							})]
						}, key))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					type: "submit",
					disabled: pending,
					children: pending ? "Saving…" : "Save settings"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "desk-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Editor grants" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "desk-note",
					children: "These emails can use the desk when sign-in is on and ADMIN_EMAILS is unset."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: data.grants.map((email) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					email,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn--ghost",
						onClick: () => {
							adminRemoveGrant({ data: { email } }).then(() => router.invalidate());
						},
						children: "Remove"
					})
				] }, email)) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "filters",
					onSubmit: (event) => {
						event.preventDefault();
						adminAddGrant({ data: { email: grant } }).then(async () => {
							setGrant("");
							setMessage("Grant saved.");
							await router.invalidate();
						}).catch((caught) => setError(errorText(caught)));
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "field",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							value: grant,
							onChange: (event) => setGrant(event.target.value),
							required: true
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Add editor"
					})]
				})
			]
		})
	] });
}
//#endregion
export { SettingsDesk as component };
