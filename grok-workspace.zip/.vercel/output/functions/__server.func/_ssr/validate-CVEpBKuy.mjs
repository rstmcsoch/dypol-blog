import { r as __exportAll } from "../_runtime.mjs";
import { n as site, t as publicationStatuses } from "./types-BLz7yWjW.mjs";
import { c as __exportAll$1 } from "./ssr.mjs";
import { _n as object, bn as string, cn as _enum, dn as boolean, fn as discriminatedUnion, mn as literal, un as array, xn as union } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/validate-CVEpBKuy.js
var validate_CVEpBKuy_exports = /* @__PURE__ */ __exportAll({
	a: () => normalizeSite,
	c: () => validate_exports,
	i: () => mediaWriteSchema,
	l: () => publishProblems,
	n: () => categoryWriteSchema,
	o: () => parseSite,
	r: () => decodeImage,
	s: () => tagWriteSchema,
	t: () => articleWriteSchema,
	u: () => slugify
});
function slugify(value) {
	return value.normalize("NFKD").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "piece";
}
function isSafeHref(value) {
	if (value.startsWith("/") && !value.startsWith("//")) return true;
	try {
		return new URL(value).protocol === "https:";
	} catch {
		return false;
	}
}
function publishProblems(input) {
	if (!input.excerpt.trim()) return "Add an excerpt before publishing.";
	if (!input.blocks.some((block) => {
		if (block.type === "list") return block.items.some((item) => item.trim());
		if (block.type === "code") return block.code.trim().length > 0;
		return block.text.trim().length > 0;
	})) return "Add at least one block before publishing.";
	return null;
}
var validate_exports = /* @__PURE__ */ __exportAll$1({
	articleListSchema: () => articleListSchema,
	articleWriteSchema: () => articleWriteSchema,
	categoryWriteSchema: () => categoryWriteSchema,
	decodeImage: () => decodeImage,
	mediaWriteSchema: () => mediaWriteSchema,
	normalizeSite: () => normalizeSite,
	parseSite: () => parseSite,
	tagWriteSchema: () => tagWriteSchema
});
var slugSchema = string().trim().min(1).max(80).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers, and hyphens.");
var blockSchema = discriminatedUnion("type", [
	object({
		type: literal("paragraph"),
		text: string().max(2e4)
	}),
	object({
		type: literal("heading"),
		level: union([literal(2), literal(3)]),
		text: string().max(300)
	}),
	object({
		type: literal("list"),
		ordered: boolean().optional(),
		items: array(string().max(2e3)).max(40)
	}),
	object({
		type: literal("quote"),
		text: string().max(5e3),
		attribution: string().max(200).optional()
	}),
	object({
		type: literal("code"),
		language: string().max(40).optional(),
		code: string().max(2e4)
	})
]);
var articleWriteSchema = object({
	id: string().min(1).max(80).nullable(),
	title: string().trim().min(1).max(200),
	slug: string().trim().max(80),
	excerpt: string().trim().max(500),
	categoryId: string().min(1).max(80),
	tagIds: array(string().min(1).max(80)).max(24),
	motif: _enum([
		"corner",
		"band",
		"split",
		"stamp",
		"stack",
		"edge"
	]),
	featured: boolean(),
	seoTitle: string().trim().max(200),
	seoDescription: string().trim().max(300),
	coverMediaId: string().min(1).max(80).nullable(),
	publishedAt: string().datetime().nullable(),
	blocks: array(blockSchema).max(80),
	intent: _enum([
		"save",
		"publish",
		"unpublish"
	])
});
var hrefSchema = string().trim().max(300).refine((value) => isSafeHref(value), "Link must be a site path or an https URL.");
var labelText = string().trim().min(1).max(80);
var siteSchema = object({
	name: string().trim().min(1).max(80),
	title: string().trim().min(1).max(120),
	description: string().trim().min(1).max(300),
	publisher: string().trim().min(1).max(80),
	labels: object({
		featured: labelText,
		also: labelText,
		latest: labelText,
		topics: labelText,
		read: labelText,
		fullIndex: labelText,
		indexKicker: labelText,
		indexTitle: labelText,
		indexLede: string().trim().min(1).max(240),
		topicsKicker: labelText,
		topicsTitle: labelText,
		topicsLede: string().trim().min(1).max(240),
		aboutKicker: labelText,
		aboutTitle: labelText,
		related: labelText,
		neighbors: labelText,
		newer: labelText,
		older: labelText,
		minRead: labelText,
		emptyTitle: string().trim().min(1).max(120),
		emptyBody: string().trim().min(1).max(240),
		emptyAction: labelText,
		notFoundKicker: labelText,
		notFoundTitle: string().trim().min(1).max(160),
		notFoundBody: string().trim().min(1).max(240),
		backHome: labelText,
		menu: labelText,
		close: labelText,
		day: labelText,
		night: labelText,
		themeGroup: labelText,
		dayTheme: string().trim().min(1).max(120),
		nightTheme: string().trim().min(1).max(120),
		skip: labelText,
		primaryNav: labelText,
		footerNav: labelText,
		errorTitle: string().trim().min(1).max(120),
		errorHome: labelText,
		loading: labelText
	}),
	nav: array(object({
		id: string().min(1).max(40),
		label: labelText,
		href: _enum([
			"/",
			"/articles",
			"/topics",
			"/about"
		]),
		visible: boolean()
	})).max(8),
	trending: object({
		enabled: boolean(),
		label: labelText,
		slugs: array(slugSchema).max(12)
	}),
	footer: object({
		note: string().trim().min(1).max(160),
		links: array(object({
			id: string().min(1).max(40),
			label: labelText,
			href: hrefSchema
		})).max(8)
	}),
	about: object({ paragraphs: array(string().trim().min(1).max(2e3)).min(1).max(12) }),
	logoMediaId: string().min(1).max(80).nullable(),
	faviconMediaId: string().min(1).max(80).nullable()
});
function normalizeSite(input) {
	const raw = input && typeof input === "object" ? input : {};
	return siteSchema.parse({
		...site,
		...raw,
		labels: {
			...site.labels,
			...raw.labels ?? {}
		},
		nav: Array.isArray(raw.nav) && raw.nav.length > 0 ? raw.nav : site.nav,
		trending: {
			...site.trending,
			...raw.trending ?? {}
		},
		footer: {
			...site.footer,
			...raw.footer ?? {},
			links: raw.footer?.links ?? site.footer.links
		},
		about: { paragraphs: Array.isArray(raw.about?.paragraphs) && raw.about.paragraphs.length > 0 ? raw.about.paragraphs : site.about.paragraphs },
		logoMediaId: raw.logoMediaId ?? null,
		faviconMediaId: raw.faviconMediaId ?? null
	});
}
function parseSite(input) {
	return siteSchema.parse(input);
}
var categoryWriteSchema = object({
	id: string().min(1).max(80).nullable(),
	label: string().trim().min(1).max(80),
	slug: string().trim().max(80),
	description: string().trim().max(400)
});
var tagWriteSchema = object({
	id: string().min(1).max(80).nullable(),
	label: string().trim().min(1).max(80),
	slug: string().trim().max(80)
});
var mediaWriteSchema = object({
	filename: string().trim().min(1).max(120),
	mime: _enum([
		"image/jpeg",
		"image/png",
		"image/webp",
		"image/gif"
	]),
	alt: string().trim().max(200),
	dataBase64: string().min(1).max(28e5)
});
var articleListSchema = object({
	q: string().trim().max(120).optional(),
	status: _enum(publicationStatuses).optional(),
	categoryId: string().max(80).optional(),
	tagId: string().max(80).optional(),
	sort: _enum([
		"updated",
		"published",
		"title"
	]).optional()
});
function decodeImage(dataBase64, mime) {
	const cleaned = dataBase64.replace(/^data:[^,]*,/, "");
	const bytes = Buffer.from(cleaned, "base64");
	if (bytes.length === 0 || bytes.length > 15e5) throw new Error("Image must be under 1.5 MB.");
	if (!matchesMime(bytes, mime)) throw new Error("That file is not the image type it claims.");
	return bytes;
}
function matchesMime(bytes, mime) {
	if (mime === "image/jpeg") return bytes[0] === 255 && bytes[1] === 216;
	if (mime === "image/png") return bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71;
	if (mime === "image/gif") return bytes.subarray(0, 3).toString("ascii") === "GIF";
	if (mime === "image/webp") return bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
	return false;
}
//#endregion
export { normalizeSite as a, slugify as c, mediaWriteSchema as i, tagWriteSchema as l, categoryWriteSchema as n, parseSite as o, decodeImage as r, publishProblems as s, articleWriteSchema as t, validate_CVEpBKuy_exports as u };
