import { S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as Route$12 } from "./router-wjzIUxJ1.mjs";
import { t as formatDate } from "./format-BabHa5xU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CEeo4y01.js
var import_jsx_runtime = require_jsx_runtime();
function DeskHome() {
	const data = Route$12.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-kicker",
			children: "Overview"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "desk-title",
			children: "Desk"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: "Counts come from the journal store. Nothing here is a sample number."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stat-grid",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.counts.published }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Published" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.counts.draft }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Drafts" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.counts.unpublished }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unpublished" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: data.media.files }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [formatBytes(data.media.bytes), " in the library"] })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "desk-section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Needs attention" }), data.attention.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "desk-note",
				children: "No drafts or unpublished pieces."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceTable, { rows: data.attention })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "desk-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Recently updated" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceTable, { rows: data.recent }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: { marginTop: "1rem" },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/articles/new",
						className: "btn",
						children: "New piece"
					})
				})
			]
		})
	] });
}
function PieceTable({ rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "desk-table-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "desk-table",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Title" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Status" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Topic" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Updated" })
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin/articles/$id",
					params: { id: row.id },
					children: row.title
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: row.status === "published" ? "desk-status desk-status--published" : "desk-status",
					children: row.status
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: row.categoryLabel }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: formatDate(row.updatedAt) })
			] }, row.id)) })]
		})
	});
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1048576) return `${Math.round(bytes / 1024)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
//#endregion
export { DeskHome as component };
