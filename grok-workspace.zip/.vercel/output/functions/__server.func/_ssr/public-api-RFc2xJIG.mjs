import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-api-RFc2xJIG.js
var getShell_createServerFn_handler = createServerRpc({
	id: "fc99ab95133833eb0ea69a8a7e2f9850423cad4c95783ff5b3cd5b9599999cc2",
	name: "getShell",
	filename: "src/content/public-api.ts"
}, (opts) => getShell.__executeServer(opts));
var getShell = createServerFn({ method: "GET" }).handler(getShell_createServerFn_handler, async () => {
	const { readShell } = await import("./repository.server-CPUCf2d_.mjs");
	return readShell();
});
var getHome_createServerFn_handler = createServerRpc({
	id: "c929b3050df5d7a139d35d884f0563df3c3ac12bb2165543068a44ad310b8852",
	name: "getHome",
	filename: "src/content/public-api.ts"
}, (opts) => getHome.__executeServer(opts));
var getHome = createServerFn({ method: "GET" }).handler(getHome_createServerFn_handler, async () => {
	const { readHome } = await import("./repository.server-CPUCf2d_.mjs");
	return readHome();
});
var getIndex_createServerFn_handler = createServerRpc({
	id: "05cf9a147c098d3bf756ea510a2efb97c67a729890ae602b753d90a0c6376ead",
	name: "getIndex",
	filename: "src/content/public-api.ts"
}, (opts) => getIndex.__executeServer(opts));
var getIndex = createServerFn({ method: "GET" }).handler(getIndex_createServerFn_handler, async () => {
	const { readIndex } = await import("./repository.server-CPUCf2d_.mjs");
	return readIndex();
});
var getTopics_createServerFn_handler = createServerRpc({
	id: "4c57f20ab77e1f917bddd3b427e4d24a36c1140056cc89eb78339f79e91b7696",
	name: "getTopics",
	filename: "src/content/public-api.ts"
}, (opts) => getTopics.__executeServer(opts));
var getTopics = createServerFn({ method: "GET" }).handler(getTopics_createServerFn_handler, async () => {
	const { readTopics } = await import("./repository.server-CPUCf2d_.mjs");
	return readTopics();
});
var getTopic_createServerFn_handler = createServerRpc({
	id: "640625f4ae5008bd82663e12856f05671de96f500f4539b8d949a75536d950e3",
	name: "getTopic",
	filename: "src/content/public-api.ts"
}, (opts) => getTopic.__executeServer(opts));
var getTopic = createServerFn({ method: "GET" }).validator((input) => input).handler(getTopic_createServerFn_handler, async ({ data }) => {
	const { readTopic } = await import("./repository.server-CPUCf2d_.mjs");
	return readTopic(data.slug);
});
var getArticle_createServerFn_handler = createServerRpc({
	id: "bd485879f4b630eb62e50301bec6c8cd1b20ca64c23dc0a4741ade678b061d41",
	name: "getArticle",
	filename: "src/content/public-api.ts"
}, (opts) => getArticle.__executeServer(opts));
var getArticle = createServerFn({ method: "GET" }).validator((input) => input).handler(getArticle_createServerFn_handler, async ({ data }) => {
	const { readArticle } = await import("./repository.server-CPUCf2d_.mjs");
	return readArticle(data.slug);
});
var getSitemapEntries_createServerFn_handler = createServerRpc({
	id: "14f3bdd9f7a7dd3234f0eb574fc4be18e277abe5ca5449d21c321735d434cc83",
	name: "getSitemapEntries",
	filename: "src/content/public-api.ts"
}, (opts) => getSitemapEntries.__executeServer(opts));
var getSitemapEntries = createServerFn({ method: "GET" }).handler(getSitemapEntries_createServerFn_handler, async () => {
	const { readSitemap } = await import("./repository.server-CPUCf2d_.mjs");
	return readSitemap();
});
//#endregion
export { getArticle_createServerFn_handler, getHome_createServerFn_handler, getIndex_createServerFn_handler, getShell_createServerFn_handler, getSitemapEntries_createServerFn_handler, getTopic_createServerFn_handler, getTopics_createServerFn_handler };
