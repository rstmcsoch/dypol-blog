import { S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as Route$15 } from "./router-wjzIUxJ1.mjs";
import "./client-CwKrMkzh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-9WPDEtPi.js
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { denied } = Route$15.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: "Sign in"
					}),
					denied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "This account is not an editor."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: "Sign-in is off in this environment. The desk is open here, and it is locked to granted accounts once sign-in is turned on."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "btn",
						children: "Open the desk"
					})] })
				]
			})
		})
	});
}
//#endregion
export { LoginPage as component };
