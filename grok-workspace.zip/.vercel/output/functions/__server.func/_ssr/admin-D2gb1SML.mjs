import { o as __toESM } from "../_runtime.mjs";
import { S as Link, T as require_jsx_runtime, _ as Outlet, et as require_react, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as Route$16 } from "./router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-D2gb1SML.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		to: "/admin",
		label: "Desk",
		exact: true
	},
	{
		to: "/admin/articles",
		label: "Pieces"
	},
	{
		to: "/admin/topics",
		label: "Topics"
	},
	{
		to: "/admin/media",
		label: "Media"
	},
	{
		to: "/admin/settings",
		label: "Settings"
	}
];
function AdminShell({ children, mode, email }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "desk",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "desk-bar",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container desk-bar-inner",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/admin",
						className: "desk-brand",
						children: ["DYPOL ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Desk" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: open ? "desk-nav is-open" : "desk-nav",
						"aria-label": "Desk",
						children: [links.map((link) => {
							const active = "exact" in link && link.exact ? pathname === link.to : pathname === link.to || pathname.startsWith(`${link.to}/`);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: link.to,
								className: active ? "is-active" : void 0,
								"aria-current": active ? "page" : void 0,
								onClick: () => setOpen(false),
								children: link.label
							}, link.to);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							onClick: () => setOpen(false),
							children: "View journal"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "desk-mode",
						children: mode === "dev" ? "Preview desk" : email ?? "Editor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "desk-nav-btn",
						"aria-expanded": open,
						onClick: () => setOpen((value) => !value),
						children: open ? "Close" : "Sections"
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "desk-main",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container",
				children
			})
		})]
	});
}
function AdminLayout() {
	const session = Route$16.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminShell, {
		mode: session.mode,
		email: session.email,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
//#endregion
export { AdminLayout as component };
