//#region node_modules/.nitro/vite/services/ssr/assets/format-BabHa5xU.js
var dateFormat = new Intl.DateTimeFormat("en-GB", {
	day: "numeric",
	month: "short",
	year: "numeric",
	timeZone: "UTC"
});
function formatDate(iso) {
	return dateFormat.format(new Date(iso));
}
function padIndex(n) {
	return String(n).padStart(2, "0");
}
//#endregion
export { padIndex as n, formatDate as t };
