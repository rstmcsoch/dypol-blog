import { t as publicationStatuses } from "./types-BLz7yWjW.mjs";
import { C as useNavigate, S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$2 } from "./router-wjzIUxJ1.mjs";
import { t as formatDate } from "./format-BabHa5xU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articles-BuhoEgSs.js
var import_jsx_runtime = require_jsx_runtime();
function ArticleIndex() {
	const data = Route$2.useLoaderData();
	const search = Route$2.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-kicker",
			children: "Pieces"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "desk-title",
			children: "Index"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "filters",
			style: { marginTop: "1rem" },
			onSubmit: (event) => {
				event.preventDefault();
				const form = new FormData(event.currentTarget);
				const read = (key) => {
					return String(form.get(key) ?? "") || void 0;
				};
				navigate({
					to: "/admin/articles",
					search: {
						q: read("q"),
						status: publicationStatuses.find((status) => status === read("status")),
						categoryId: read("categoryId"),
						tagId: read("tagId"),
						sort: read("sort") === "title" || read("sort") === "published" ? read("sort") : void 0
					}
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Search title or slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "q",
						defaultValue: search.q ?? ""
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "status",
						defaultValue: search.status ?? "",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Any"
						}), publicationStatuses.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: status,
							children: status
						}, status))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Topic" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "categoryId",
						defaultValue: search.categoryId ?? "",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Any"
						}), data.categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: category.id,
							children: category.label
						}, category.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tag" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "tagId",
						defaultValue: search.tagId ?? "",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Any"
						}), data.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: tag.id,
							children: tag.label
						}, tag.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sort" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						name: "sort",
						defaultValue: search.sort ?? "updated",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "updated",
								children: "Updated"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "published",
								children: "Published"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "title",
								children: "Title"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					type: "submit",
					children: "Filter"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			style: { margin: "1rem 0" },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/admin/articles/new",
				className: "btn",
				children: "New piece"
			})
		}),
		data.articles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: "Nothing matches."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "desk-table-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "desk-table",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Title" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Topic" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Updated" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.articles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/articles/$id",
						params: { id: article.id },
						children: article.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "desk-note",
						children: article.slug
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: article.status === "published" ? "desk-status desk-status--published" : "desk-status",
						children: [article.status, article.featured ? " · featured" : ""]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: article.categoryLabel }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: formatDate(article.updatedAt) })
				] }, article.id)) })]
			})
		})
	] });
}
//#endregion
export { ArticleIndex as component };
