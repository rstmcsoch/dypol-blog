import { n as site } from "./types-BLz7yWjW.mjs";
import { t as readingMinutes } from "./present-Dcl3727_.mjs";
import { a as normalizeSite, c as slugify, i as mediaWriteSchema, l as tagWriteSchema, n as categoryWriteSchema, o as parseSite, r as decodeImage, s as publishProblems, t as articleWriteSchema } from "./validate-CVEpBKuy.mjs";
import { i as withTransaction, r as getSql } from "./db-BEOxeoR1.mjs";
import { MediaBindingError, openMediaStore } from "./media-store.server-B9cUOc91.mjs";
import { randomUUID } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/repository.server-CPUCf2d_.js
var articles = [
	{
		id: "art-quiet-architecture",
		slug: "quiet-architecture-of-a-page",
		title: "The quiet architecture of a published page",
		excerpt: "A page worth reading is mostly structure: a title, a time, a place in the index, and a body that does not fight the measure.",
		status: "published",
		publishedAt: "2026-10-04T08:00:00.000Z",
		updatedAt: "2026-10-04T08:00:00.000Z",
		categoryId: "systems",
		tagIds: ["structure", "layout"],
		motif: "corner",
		featured: true,
		blocks: [
			{
				type: "paragraph",
				text: "Most of what makes a journal feel finished is invisible. The reader meets a title, a date, and a column of type. Under that, the page has already decided what a piece is allowed to be."
			},
			{
				type: "heading",
				level: 2,
				text: "One shape, used everywhere"
			},
			{
				type: "paragraph",
				text: "A piece needs a stable identity: a slug that does not change, a status that is explicit, a category, and a body made of known blocks. If the public page, the editor, and an automated submission all speak that same shape, nothing has to be translated on the way out."
			},
			{
				type: "list",
				items: [
					"Draft means it is not on the public index.",
					"Published means a reader can open it.",
					"Unpublished means it was pulled, and it stays out of the index."
				]
			},
			{
				type: "heading",
				level: 2,
				text: "What the page refuses"
			},
			{
				type: "paragraph",
				text: "The body is not a bucket of unmarked HTML. Paragraphs, headings, lists, quotations, and code are separate. That keeps the reading column predictable and keeps a bad paste from becoming the layout."
			},
			{
				type: "quote",
				text: "If a field can be guessed, an automated writer will guess it wrong. Name it."
			},
			{
				type: "paragraph",
				text: "The sample essays in this journal exist to show that structure. They are not a history of the lab. They are a demonstration of the page."
			}
		]
	},
	{
		id: "art-hard-edge",
		slug: "hard-edge-returns",
		title: "Borders, type, and the return of the hard edge",
		excerpt: "A hard edge is not decoration. It is how a publication tells you where one thing ends and the next begins.",
		status: "published",
		publishedAt: "2026-10-01T08:00:00.000Z",
		updatedAt: "2026-10-01T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["type", "layout"],
		motif: "split",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "Soft cards and blurred shadows make everything feel like the same surface. A journal needs the opposite: a rule you can see, a shadow that is honestly offset, a corner that does not pretend to be a pebble."
			},
			{
				type: "heading",
				level: 2,
				text: "Black, white, then one color"
			},
			{
				type: "paragraph",
				text: "The day page is white. The night page is black. Those two carry the structure. A single orange is allowed on a stamp, a band, or a plate — and only there does the grain appear. The type stays clean."
			},
			{
				type: "paragraph",
				text: "Headlines can be loud. Body text cannot. The column stays narrow enough to read, and the type size does not jump just because the screen is wide."
			}
		]
	},
	{
		id: "art-machine",
		slug: "what-a-machine-should-send",
		title: "What a machine should send when it publishes",
		excerpt: "An automated writer should submit a document, not pretend to click through a form. The document has to be the same one a person would save.",
		status: "published",
		publishedAt: "2026-09-26T08:00:00.000Z",
		updatedAt: "2026-09-26T08:00:00.000Z",
		categoryId: "systems",
		tagIds: ["workflow", "structure"],
		motif: "band",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "If a publishing flow depends on a particular model, a particular vendor, or a screen full of buttons, it will break the moment any of those change. The durable part is the payload."
			},
			{
				type: "heading",
				level: 2,
				text: "A payload, not a performance"
			},
			{
				type: "paragraph",
				text: "The useful submission names its fields, validates them, and returns a clear success or a list of errors. It can be retried. It does not invent a second article format for machines."
			},
			{
				type: "code",
				language: "json",
				code: "{\n  \"slug\": \"working-title\",\n  \"status\": \"draft\",\n  \"title\": \"Working title\",\n  \"categoryId\": \"systems\"\n}"
			},
			{
				type: "paragraph",
				text: "A person using an editor later should produce this same object. The public page should render this same object. The agent is replaceable. The article is not."
			}
		]
	},
	{
		id: "art-reading-width",
		slug: "reading-width",
		title: "Reading width is a product decision",
		excerpt: "A line that runs the full width of a monitor is not generous. It is harder to read. The measure should stay put.",
		status: "published",
		publishedAt: "2026-09-20T08:00:00.000Z",
		updatedAt: "2026-09-20T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["type", "layout"],
		motif: "edge",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "On a phone, the danger is type that is too big for the screen and margins that disappear. On a desktop, the danger is a paragraph that stretches until the eye loses the next line."
			},
			{
				type: "paragraph",
				text: "A reading column around sixty-six characters solves the second problem without making the first one worse. Headlines can be wider. The body should not copy them."
			},
			{
				type: "heading",
				level: 2,
				text: "Metadata stays out of the way"
			},
			{
				type: "paragraph",
				text: "Date, topic, and length belong near the title, in a smaller voice. They should not become a second article. If they wrap on a narrow screen, they wrap. They do not overflow."
			}
		]
	},
	{
		id: "art-index",
		slug: "an-index-not-a-feed",
		title: "An index, not a feed",
		excerpt: "A journal can show what it has without pretending the list is infinite. Numbers, rules, and titles are enough.",
		status: "published",
		publishedAt: "2026-09-14T08:00:00.000Z",
		updatedAt: "2026-09-14T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["index", "layout"],
		motif: "stack",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "A feed asks you to keep scrolling. An index tells you where you are. For a small publication, the index is the more honest object: a numbered list, a topic, a date, a title you can scan."
			},
			{
				type: "paragraph",
				text: "The homepage can still lead with one piece. The rest of the journal does not need to become a grid of identical cards. A rule between rows is a clearer invitation."
			},
			{
				type: "list",
				ordered: true,
				items: [
					"Put the newest piece where the eye lands first.",
					"Give the next few a shared band, not a new visual system.",
					"Let the remainder be a list."
				]
			}
		]
	},
	{
		id: "art-three-states",
		slug: "three-states",
		title: "Draft, published, withdrawn",
		excerpt: "A piece should not be public because somebody forgot a checkbox. The state is part of the article, and the index trusts it.",
		status: "published",
		publishedAt: "2026-09-08T08:00:00.000Z",
		updatedAt: "2026-09-08T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["workflow", "structure"],
		motif: "stamp",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "Three states are enough until a newsroom actually needs more. Draft: still being written. Published: on the site. Unpublished: kept, but not listed and not readable at its old address."
			},
			{
				type: "paragraph",
				text: "The public site never infers this from a missing date or a hidden flag buried in a template. Queries ask for published pieces and ignore the rest. A topic with only drafts looks empty on purpose."
			},
			{
				type: "quote",
				text: "Empty is a real state. It should look like the rest of the journal, not like a missing page."
			}
		]
	},
	{
		id: "art-frame",
		slug: "the-frame-around-a-picture",
		title: "The frame around a picture",
		excerpt: "Media should sit in a frame that already has a size. The page must not jump when the file arrives, and the picture must not stretch.",
		status: "published",
		publishedAt: "2026-09-02T08:00:00.000Z",
		updatedAt: "2026-09-02T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["media", "layout"],
		motif: "corner",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "A cover is a promise about the piece, not a second layout. It keeps a fixed ratio, it has a description if it is a real image, and it loads after the title when it is not the first thing on the screen."
			},
			{
				type: "paragraph",
				text: "Until a piece has a picture, the frame can still be a plate: a number, a topic, a block of color. The plate is the same component the photograph will replace. The page does not grow a new hole."
			},
			{
				type: "heading",
				level: 2,
				text: "Grain stays on the color"
			},
			{
				type: "paragraph",
				text: "Noise on white type makes a page look dirty. Noise on an orange field looks like print. The frame uses the second one and leaves the headline alone."
			}
		]
	},
	{
		id: "art-notes-draft",
		slug: "desk-notes",
		title: "Desk notes",
		excerpt: "A draft that should not appear on the public index.",
		status: "draft",
		publishedAt: null,
		updatedAt: "2026-10-05T08:00:00.000Z",
		categoryId: "notes",
		tagIds: ["workflow"],
		motif: "edge",
		featured: false,
		blocks: [{
			type: "paragraph",
			text: "This draft exists so the public queries have something to exclude. It is not a published essay."
		}]
	},
	{
		id: "art-withdrawn",
		slug: "withdrawn-note",
		title: "A note that was withdrawn",
		excerpt: "An unpublished piece. It stays in the record and off the site.",
		status: "unpublished",
		publishedAt: "2026-08-01T08:00:00.000Z",
		updatedAt: "2026-08-20T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["workflow"],
		motif: "band",
		featured: false,
		blocks: [{
			type: "paragraph",
			text: "This piece was withdrawn. The public index should not list it, and its address should not resolve."
		}]
	}
];
var categories = [
	{
		id: "systems",
		slug: "systems",
		label: "Systems",
		description: "How a publication is structured, stored, and handed from one step to the next."
	},
	{
		id: "design",
		slug: "design",
		label: "Design",
		description: "Type, edges, images, and the decisions that keep a long page readable."
	},
	{
		id: "publishing",
		slug: "publishing",
		label: "Publishing",
		description: "How a piece moves from a draft to something a reader can find."
	},
	{
		id: "notes",
		slug: "notes",
		label: "Notes",
		description: "Short filings. This topic is empty until something here is published."
	}
];
var tags = [
	{
		id: "structure",
		slug: "structure",
		label: "Structure"
	},
	{
		id: "type",
		slug: "type",
		label: "Type"
	},
	{
		id: "layout",
		slug: "layout",
		label: "Layout"
	},
	{
		id: "media",
		slug: "media",
		label: "Media"
	},
	{
		id: "workflow",
		slug: "workflow",
		label: "Workflow"
	},
	{
		id: "index",
		slug: "index",
		label: "Index"
	}
];
var ContentError = class extends Error {
	status;
	constructor(message, status = 400) {
		super(message);
		this.name = "ContentError";
		this.status = status;
	}
};
var readyState = globalThis;
function ensureContent() {
	readyState.__dypolContentReady__ ??= seedIfEmpty().catch((error) => {
		readyState.__dypolContentReady__ = void 0;
		throw error;
	});
	return readyState.__dypolContentReady__;
}
async function seedIfEmpty() {
	await withTransaction(async (sql) => {
		const existing = await sql`select count(*)::int as n from articles`;
		if (Number(existing[0]?.n ?? 0) > 0) {
			if ((await sql`select id from site_settings where id = 'site'`).length === 0) await sql`insert into site_settings (id, data) values ('site', ${JSON.stringify(site)}::jsonb)`;
			return;
		}
		for (const category of categories) await sql`insert into categories (id, slug, label, description) values (${category.id}, ${category.slug}, ${category.label}, ${category.description})`;
		for (const tag of tags) await sql`insert into tags (id, slug, label) values (${tag.id}, ${tag.slug}, ${tag.label})`;
		for (const article of articles) {
			await sql`insert into articles (
        id, slug, title, excerpt, status, published_at, updated_at, category_id, motif, featured,
        seo_title, seo_description, cover_media_id, blocks
      ) values (
        ${article.id}, ${article.slug}, ${article.title}, ${article.excerpt}, ${article.status},
        ${article.publishedAt}, ${article.updatedAt}, ${article.categoryId}, ${article.motif},
        ${article.featured}, ${article.seoTitle ?? null}, ${article.seoDescription ?? null},
        ${article.coverMediaId ?? null}, ${JSON.stringify(article.blocks)}::jsonb
      )`;
			for (const tagId of article.tagIds) await sql`insert into article_tags (article_id, tag_id) values (${article.id}, ${tagId})`;
		}
		await sql`insert into site_settings (id, data) values ('site', ${JSON.stringify(site)}::jsonb)`;
	});
}
function iso(value) {
	if (!value) return null;
	if (value instanceof Date) return value.toISOString();
	const parsed = new Date(value);
	return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toISOString();
}
function mapArticle(row, tagIds) {
	const blocks = typeof row.blocks === "string" ? JSON.parse(row.blocks) : row.blocks;
	return {
		id: row.id,
		slug: row.slug,
		title: row.title,
		excerpt: row.excerpt,
		status: row.status,
		publishedAt: iso(row.published_at),
		updatedAt: iso(row.updated_at) ?? (/* @__PURE__ */ new Date(0)).toISOString(),
		categoryId: row.category_id,
		tagIds,
		motif: row.motif,
		featured: row.featured,
		seoTitle: row.seo_title ?? void 0,
		seoDescription: row.seo_description ?? void 0,
		coverMediaId: row.cover_media_id,
		blocks
	};
}
async function tagMap(sql, ids) {
	const map = /* @__PURE__ */ new Map();
	if (ids.length === 0) return map;
	const placeholders = ids.map((_, index) => `$${index + 1}`).join(", ");
	const links = await sql.query(`select article_id, tag_id from article_tags where article_id in (${placeholders})`, ids);
	for (const link of links) {
		const list = map.get(link.article_id) ?? [];
		list.push(link.tag_id);
		map.set(link.article_id, list);
	}
	return map;
}
async function loadArticles(sql, where = "", params = []) {
	const rows = await sql.query(`select id, slug, title, excerpt, status, published_at, updated_at, category_id, motif, featured,
            seo_title, seo_description, cover_media_id, blocks
     from articles ${where}`, params);
	const tags = await tagMap(sql, rows.map((row) => row.id));
	return rows.map((row) => mapArticle(row, tags.get(row.id) ?? []));
}
function byNewest(a, b) {
	return Date.parse(b.publishedAt ?? "") - Date.parse(a.publishedAt ?? "");
}
async function catalog() {
	await ensureContent();
	const sql = await getSql();
	const articles = await loadArticles(sql, "order by updated_at desc");
	const categories = await sql`select id, slug, label, description from categories order by label asc`;
	const tags = await sql`select id, slug, label from tags order by label asc`;
	const raw = (await sql`select data from site_settings where id = 'site'`)[0]?.data;
	return {
		articles,
		categories,
		tags,
		site: normalizeSite(typeof raw === "string" ? JSON.parse(raw) : raw)
	};
}
function published(articles) {
	return articles.filter((article) => article.status === "published" && article.publishedAt).sort(byNewest);
}
function categoryOf(categories, idOrSlug) {
	return categories.find((category) => category.id === idOrSlug || category.slug === idOrSlug);
}
function metaFor(articles, publishedOrder, categories) {
	const meta = {};
	for (const article of articles) {
		const rank = publishedOrder.findIndex((item) => item.id === article.id);
		meta[article.id] = {
			rank: rank === -1 ? 0 : rank + 1,
			categoryLabel: categoryOf(categories, article.categoryId)?.label ?? "",
			minutes: readingMinutes(article)
		};
	}
	return meta;
}
async function readShell() {
	const data = await catalog();
	const live = published(data.articles);
	const trending = data.site.trending.enabled ? data.site.trending.slugs.map((slug) => live.find((article) => article.slug === slug)).filter((article) => Boolean(article)).map((article) => ({
		id: article.id,
		slug: article.slug,
		title: article.title
	})) : [];
	return {
		site: data.site,
		trending
	};
}
async function readHome() {
	const data = await catalog();
	const live = published(data.articles);
	const lead = live.find((article) => article.featured) ?? live[0] ?? null;
	const rest = live.filter((article) => article.id !== lead?.id);
	const band = rest.slice(0, 3);
	const index = rest.slice(3);
	return {
		lead,
		band,
		index,
		meta: metaFor([
			...lead ? [lead] : [],
			...band,
			...index
		], live, data.categories),
		topics: data.categories.map((category) => ({
			category,
			count: live.filter((article) => article.categoryId === category.id).length
		}))
	};
}
async function readIndex() {
	const data = await catalog();
	const live = published(data.articles);
	return {
		articles: live,
		meta: metaFor(live, live, data.categories)
	};
}
async function readTopics() {
	const data = await catalog();
	const live = published(data.articles);
	return { topics: data.categories.map((category) => ({
		category,
		count: live.filter((article) => article.categoryId === category.id).length
	})) };
}
async function readTopic(slug) {
	const data = await catalog();
	const category = categoryOf(data.categories, slug);
	if (!category) return null;
	const live = published(data.articles).filter((article) => article.categoryId === category.id);
	return {
		category,
		articles: live,
		meta: metaFor(live, published(data.articles), data.categories)
	};
}
async function readArticle(slug) {
	const data = await catalog();
	const live = published(data.articles);
	const article = live.find((item) => item.slug === slug);
	if (!article) return null;
	return articlePayload(data, article, live);
}
async function readPreview(id) {
	const data = await catalog();
	const article = data.articles.find((item) => item.id === id);
	if (!article) return null;
	return articlePayload(data, article, published(data.articles));
}
function articlePayload(data, article, live) {
	const index = live.findIndex((item) => item.id === article.id);
	const same = live.filter((item) => item.categoryId === article.categoryId && item.id !== article.id);
	const rest = live.filter((item) => item.id !== article.id && !same.some((picked) => picked.id === item.id));
	const related = [...same, ...rest].slice(0, 3);
	return {
		article,
		category: categoryOf(data.categories, article.categoryId) ?? null,
		tags: article.tagIds.map((id) => data.tags.find((tag) => tag.id === id)).filter((tag) => Boolean(tag)),
		related,
		neighbors: {
			newer: index > 0 ? live[index - 1] : void 0,
			older: index >= 0 ? live[index + 1] : void 0
		},
		rank: index === -1 ? 0 : index + 1,
		meta: metaFor(related, live, data.categories)
	};
}
async function readSitemap() {
	const data = await catalog();
	return {
		articles: published(data.articles).map((article) => article.slug),
		topics: data.categories.map((category) => category.slug)
	};
}
async function adminOverview() {
	const data = await catalog();
	const counts = {
		published: data.articles.filter((article) => article.status === "published").length,
		draft: data.articles.filter((article) => article.status === "draft").length,
		unpublished: data.articles.filter((article) => article.status === "unpublished").length,
		topics: data.categories.length,
		tags: data.tags.length
	};
	const library = await openMediaStore().catch((error) => {
		if (error instanceof MediaBindingError) return null;
		throw error;
	});
	const media = library ? await library.stats() : {
		files: 0,
		bytes: 0
	};
	const recent = [...data.articles].sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)).slice(0, 6).map((article) => summarize(article, data.categories));
	const attention = data.articles.filter((article) => article.status !== "published").sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)).slice(0, 6).map((article) => summarize(article, data.categories));
	return {
		counts,
		media: {
			files: media.files,
			bytes: media.bytes
		},
		recent,
		attention
	};
}
function summarize(article, categories) {
	return {
		id: article.id,
		slug: article.slug,
		title: article.title,
		excerpt: article.excerpt,
		status: article.status,
		publishedAt: article.publishedAt,
		updatedAt: article.updatedAt,
		categoryId: article.categoryId,
		categoryLabel: categoryOf(categories, article.categoryId)?.label ?? "",
		tagIds: article.tagIds,
		featured: article.featured
	};
}
async function adminList(input) {
	const data = await catalog();
	const q = input.q?.trim().toLowerCase() ?? "";
	let rows = data.articles.filter((article) => {
		if (input.status && article.status !== input.status) return false;
		if (input.categoryId && article.categoryId !== input.categoryId) return false;
		if (input.tagId && !article.tagIds.includes(input.tagId)) return false;
		if (!q) return true;
		return article.title.toLowerCase().includes(q) || article.slug.toLowerCase().includes(q);
	});
	rows = [...rows].sort((a, b) => {
		if (input.sort === "title") return a.title.localeCompare(b.title);
		if (input.sort === "published") return Date.parse(b.publishedAt ?? "") - Date.parse(a.publishedAt ?? "");
		return Date.parse(b.updatedAt) - Date.parse(a.updatedAt);
	});
	return {
		articles: rows.map((article) => summarize(article, data.categories)),
		categories: data.categories,
		tags: data.tags
	};
}
async function adminEditor(id) {
	const data = await catalog();
	const library = await openMediaStore().catch((error) => {
		if (error instanceof MediaBindingError) return null;
		throw error;
	});
	const media = library ? (await library.list()).map((item) => ({
		id: item.id,
		filename: item.filename,
		alt: item.alt
	})) : [];
	return {
		article: id ? data.articles.find((item) => item.id === id) ?? null : null,
		categories: data.categories,
		tags: data.tags,
		media,
		publishedSlugs: published(data.articles).map((item) => item.slug)
	};
}
async function uniqueSlug(sql, base, ignoreId) {
	let slug = slugify(base);
	let n = 2;
	for (;;) {
		const rows = await sql`select id from articles where slug = ${slug}`;
		if (rows.length === 0 || rows[0]?.id === ignoreId) return slug;
		slug = `${slugify(base).slice(0, 70)}-${n}`;
		n += 1;
	}
}
async function saveArticle(raw) {
	const input = articleWriteSchema.parse(raw);
	if (input.intent === "publish") {
		const problem = publishProblems(input);
		if (problem) throw new ContentError(problem);
	}
	await ensureContent();
	if (input.coverMediaId) {
		if (!await (await openMediaStore()).exists(input.coverMediaId)) throw new ContentError("That cover image is not in the library.");
	}
	return withTransaction(async (sql) => {
		if ((await sql`select id from categories where id = ${input.categoryId}`).length === 0) throw new ContentError("Choose a topic that exists.");
		if ((input.tagIds.length ? await sql.query(`select id from tags where id in (${input.tagIds.map((_, i) => `$${i + 1}`).join(", ")})`, input.tagIds) : []).length !== input.tagIds.length) throw new ContentError("One of the tags no longer exists.");
		const existing = input.id ? await sql`
          select id, status, published_at from articles where id = ${input.id}
        ` : [];
		if (input.id && existing.length === 0) throw new ContentError("That piece is not in the index.", 404);
		const id = input.id ?? randomUUID();
		const slug = await uniqueSlug(sql, input.slug || input.title, id);
		const previous = existing[0];
		let status = previous?.status ?? "draft";
		let publishedAt = iso(previous?.published_at ?? null);
		if (input.intent === "publish") {
			status = "published";
			publishedAt = input.publishedAt ?? publishedAt ?? (/* @__PURE__ */ new Date()).toISOString();
		} else if (input.intent === "unpublish") status = "unpublished";
		else if (input.publishedAt && status === "published") publishedAt = input.publishedAt;
		const seoTitle = input.seoTitle || null;
		const seoDescription = input.seoDescription || null;
		const blocks = JSON.stringify(input.blocks);
		const now = (/* @__PURE__ */ new Date()).toISOString();
		if (previous) await sql`update articles set
        slug = ${slug},
        title = ${input.title},
        excerpt = ${input.excerpt},
        status = ${status},
        published_at = ${publishedAt},
        updated_at = ${now},
        category_id = ${input.categoryId},
        motif = ${input.motif},
        featured = ${input.featured},
        seo_title = ${seoTitle},
        seo_description = ${seoDescription},
        cover_media_id = ${input.coverMediaId},
        blocks = ${blocks}::jsonb
        where id = ${id}`;
		else await sql`insert into articles (
        id, slug, title, excerpt, status, published_at, updated_at, category_id, motif, featured,
        seo_title, seo_description, cover_media_id, blocks
      ) values (
        ${id}, ${slug}, ${input.title}, ${input.excerpt}, ${status}, ${publishedAt}, ${now},
        ${input.categoryId}, ${input.motif}, ${input.featured}, ${seoTitle}, ${seoDescription},
        ${input.coverMediaId}, ${blocks}::jsonb
      )`;
		if (input.featured) await sql`update articles set featured = false where id <> ${id} and featured = true`;
		await sql`delete from article_tags where article_id = ${id}`;
		for (const tagId of input.tagIds) await sql`insert into article_tags (article_id, tag_id) values (${id}, ${tagId})`;
		return {
			id,
			slug,
			status
		};
	});
}
async function deleteDraft(id) {
	await ensureContent();
	const sql = await getSql();
	const rows = await sql`select status from articles where id = ${id}`;
	if (rows.length === 0) throw new ContentError("That piece is not in the index.", 404);
	if (rows[0]?.status === "published") throw new ContentError("Unpublish a piece before deleting it.");
	await sql`delete from articles where id = ${id}`;
}
async function saveCategory(raw) {
	const input = categoryWriteSchema.parse(raw);
	await ensureContent();
	const sql = await getSql();
	const slug = await uniqueTaxonomySlug(sql, "categories", input.slug || input.label, input.id);
	if (input.id) {
		if ((await sql`select id from categories where id = ${input.id}`).length === 0) throw new ContentError("That topic is gone.", 404);
		await sql`update categories set slug = ${slug}, label = ${input.label}, description = ${input.description} where id = ${input.id}`;
		return { id: input.id };
	}
	const id = slug;
	await sql`insert into categories (id, slug, label, description) values (${id}, ${slug}, ${input.label}, ${input.description})`;
	return { id };
}
async function deleteCategory(id) {
	await ensureContent();
	const sql = await getSql();
	const used = await sql`select count(*)::int as n from articles where category_id = ${id}`;
	if (Number(used[0]?.n ?? 0) > 0) throw new ContentError("Move the pieces in this topic before deleting it.");
	if ((await sql`delete from categories where id = ${id} returning id`).length === 0) throw new ContentError("That topic is gone.", 404);
}
async function saveTag(raw) {
	const input = tagWriteSchema.parse(raw);
	await ensureContent();
	const sql = await getSql();
	const slug = await uniqueTaxonomySlug(sql, "tags", input.slug || input.label, input.id);
	if (input.id) {
		if ((await sql`select id from tags where id = ${input.id}`).length === 0) throw new ContentError("That tag is gone.", 404);
		await sql`update tags set slug = ${slug}, label = ${input.label} where id = ${input.id}`;
		return { id: input.id };
	}
	const id = slug;
	await sql`insert into tags (id, slug, label) values (${id}, ${slug}, ${input.label})`;
	return { id };
}
async function deleteTag(id) {
	await ensureContent();
	const sql = await getSql();
	const used = await sql`select count(*)::int as n from article_tags where tag_id = ${id}`;
	if (Number(used[0]?.n ?? 0) > 0) throw new ContentError("Remove this tag from its pieces before deleting it.");
	if ((await sql`delete from tags where id = ${id} returning id`).length === 0) throw new ContentError("That tag is gone.", 404);
}
async function uniqueTaxonomySlug(sql, table, base, ignoreId) {
	let slug = slugify(base);
	let n = 2;
	for (;;) {
		const rows = await sql.query(`select id from ${table} where slug = $1`, [slug]);
		if (rows.length === 0 || rows[0]?.id === ignoreId) return slug;
		slug = `${slugify(base).slice(0, 70)}-${n}`;
		n += 1;
	}
}
async function readSettings() {
	const data = await catalog();
	const live = published(data.articles);
	return {
		site: data.site,
		articles: live.map((article) => ({
			slug: article.slug,
			title: article.title
		}))
	};
}
async function saveSettings(raw) {
	const next = parseSite(raw);
	await ensureContent();
	if (next.logoMediaId || next.faviconMediaId) {
		const library = await openMediaStore();
		if (next.logoMediaId && !await library.exists(next.logoMediaId)) throw new ContentError("The logo image is not in the library.");
		if (next.faviconMediaId && !await library.exists(next.faviconMediaId)) throw new ContentError("The favicon image is not in the library.");
	}
	const sql = await getSql();
	const known = new Set(published(await loadArticles(sql)).map((article) => article.slug));
	next.trending.slugs = next.trending.slugs.filter((slug) => known.has(slug));
	await sql`update site_settings set data = ${JSON.stringify(next)}::jsonb where id = 'site'`;
}
async function listMedia() {
	return (await openMediaStore()).list();
}
async function uploadMedia(raw) {
	const input = mediaWriteSchema.parse(raw);
	const bytes = decodeImage(input.dataBase64, input.mime);
	const library = await openMediaStore();
	const id = randomUUID();
	const filename = input.filename.replace(/[/\\]/g, "").slice(0, 120);
	await library.put({
		id,
		filename,
		mime: input.mime,
		alt: input.alt,
		bytes,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	});
	return { id };
}
async function deleteMedia(id) {
	await ensureContent();
	const sql = await getSql();
	const used = await sql`select count(*)::int as n from articles where cover_media_id = ${id}`;
	if (Number(used[0]?.n ?? 0) > 0) throw new ContentError("This image is a cover. Clear it from the piece first.");
	const settings = await sql`select data from site_settings where id = 'site'`;
	const config = normalizeSite(typeof settings[0]?.data === "string" ? JSON.parse(settings[0].data) : settings[0]?.data);
	if (config.logoMediaId === id || config.faviconMediaId === id) throw new ContentError("This image is used as the logo or favicon. Clear it in settings first.");
	if (!await (await openMediaStore()).remove(id)) throw new ContentError("That file is gone.", 404);
}
async function readMediaFile(id) {
	return (await openMediaStore()).read(id);
}
//#endregion
export { adminEditor, adminList, adminOverview, deleteCategory, deleteDraft, deleteMedia, deleteTag, listMedia, readArticle, readHome, readIndex, readMediaFile, readPreview, readSettings, readShell, readSitemap, readTopic, readTopics, saveArticle, saveCategory, saveSettings, saveTag, uploadMedia };
