//#region node_modules/.nitro/vite/services/ssr/assets/db-BEOxeoR1.js
var _0001_content_default = "-- Canonical journal store: articles, taxonomy, site configuration, and media.\n-- Applied once by the existing migrator (Neon on deploy, PGLite in preview).\n\ncreate table if not exists categories (\n  id text primary key,\n  slug text not null unique,\n  label text not null,\n  description text not null default ''\n);\n\ncreate table if not exists tags (\n  id text primary key,\n  slug text not null unique,\n  label text not null\n);\n\ncreate table if not exists articles (\n  id text primary key,\n  slug text not null unique,\n  title text not null,\n  excerpt text not null default '',\n  status text not null check (status in ('draft', 'published', 'unpublished')),\n  published_at timestamptz,\n  updated_at timestamptz not null default now(),\n  category_id text not null references categories (id),\n  motif text not null check (motif in ('corner', 'band', 'split', 'stamp', 'stack', 'edge')),\n  featured boolean not null default false,\n  seo_title text,\n  seo_description text,\n  cover_media_id text,\n  blocks jsonb not null\n);\n\ncreate table if not exists article_tags (\n  article_id text not null references articles (id) on delete cascade,\n  tag_id text not null references tags (id),\n  primary key (article_id, tag_id)\n);\n\ncreate table if not exists site_settings (\n  id text primary key,\n  data jsonb not null\n);\n\ncreate table if not exists media (\n  id text primary key,\n  filename text not null,\n  mime text not null,\n  alt text not null default '',\n  bytes bytea not null,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists admin_grants (\n  email text primary key\n);\n\ncreate index if not exists articles_status_idx on articles (status);\ncreate index if not exists articles_updated_idx on articles (updated_at desc);\n";
var _0002_blog_default = "create table if not exists categories (\n  id text primary key,\n  slug text not null unique,\n  label text not null,\n  description text not null\n);\n\ncreate table if not exists tags (\n  id text primary key,\n  slug text not null unique,\n  label text not null\n);\n\ncreate table if not exists articles (\n  id text primary key,\n  slug text not null unique,\n  title text not null,\n  excerpt text not null,\n  status text not null check (status in ('draft','published','unpublished')),\n  published_at timestamptz,\n  updated_at timestamptz not null,\n  category_id text not null references categories(id),\n  motif text not null check (motif in ('corner','band','split','stamp','stack','edge')),\n  featured boolean not null default false,\n  seo_title text,\n  seo_description text,\n  blocks jsonb not null\n);\n\ncreate table if not exists article_tags (\n  article_id text not null references articles(id) on delete cascade,\n  tag_id text not null references tags(id) on delete cascade,\n  primary key (article_id, tag_id)\n);\n\ncreate index if not exists articles_status_published_idx\n  on articles(status, published_at desc);\n\ncreate index if not exists articles_category_idx\n  on articles(category_id);\n";
var _0002_media_refs_default = "-- Image bytes are not stored in Postgres. They belong in the MEDIA R2 bucket,\n-- with the row kept in D1. Drop the blob column added before that binding was wired.\nalter table media drop column if exists bytes;\n";
var _0003_media_d1_default = "-- Image bytes and the media catalog live on the existing Cloudflare bindings:\n--   MEDIA  R2 bucket dypol-blog-media\n--   DB     D1 database dypol-blog-db (table media)\n-- Postgres keeps references only. Drop the earlier blob table if it was created.\n\nalter table articles add column if not exists cover_media_id text;\n\ndrop table if exists media;\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.n);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		globalRef.__pgPool__ = pool;
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("@electric-sql/pglite");
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({
			"/migrations/0001_content.sql": _0001_content_default,
			"/migrations/0002_blog.sql": _0002_blog_default,
			"/migrations/0002_media_refs.sql": _0002_media_refs_default,
			"/migrations/0003_media_d1.sql": _0003_media_d1_default
		});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Run several statements on one connection. Article saves and the first seed
* touch more than one table and need to commit together. Neon checks out a
* pooled client; PGLite uses its transaction helper. The shared `Sql` surface
* is the same one queries already use.
*/
async function withTransaction(fn) {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call withTransaction() from a createServerFn handler or a server route loader, never from client code.");
	await getSql();
	if (dbSource === "pglite") {
		const pg = await globalRef.__pgliteInstance__;
		if (!pg) throw new Error("PGLite instance failed to initialize");
		return pg.transaction(async (tx) => fn(toSql(async (text, params) => {
			return (await tx.query(text, params)).rows;
		})));
	}
	const pool = globalRef.__pgPool__;
	if (!pool) throw new Error("Postgres pool failed to initialize");
	const client = await pool.connect();
	try {
		await client.query("BEGIN");
		const result = await fn(toSql(async (text, params) => {
			return (await client.query(text, params)).rows;
		}));
		await client.query("COMMIT");
		return result;
	} catch (error) {
		try {
			await client.query("ROLLBACK");
		} catch {}
		throw error;
	} finally {
		client.release();
	}
}
/**
* The shared PGLite instance (preview only), with `migrations/*.sql` applied.
* Lets Better Auth persist to the SAME embedded DB as app data in preview (via a
* Kysely dialect). Throws when `DATABASE_URL` is set (that path uses Neon).
*/
async function getPglite() {
	if (dbSource !== "pglite") throw new Error("getPglite() is only available on the PGLite fallback (no DATABASE_URL)");
	await getSql();
	const pg = await globalRef.__pgliteInstance__;
	if (!pg) throw new Error("PGLite instance failed to initialize");
	return pg;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
//#endregion
export { withTransaction as i, getPglite as n, getSql as r, ensureDbReady as t };
