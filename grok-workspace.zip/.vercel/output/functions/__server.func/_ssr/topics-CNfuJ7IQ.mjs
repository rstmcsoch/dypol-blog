import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useSite } from "./use-site-ChaMm9lO.mjs";
import { o as Route$4 } from "./router-wjzIUxJ1.mjs";
import { t as TopicGrid } from "./topic-grid-B1ZyDRBA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topics-CNfuJ7IQ.js
var import_jsx_runtime = require_jsx_runtime();
function TopicsPage() {
	const site = useSite();
	const { topics } = Route$4.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.topicsKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: site.labels.topicsTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: site.labels.topicsLede
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicGrid, { topics })]
		})
	});
}
//#endregion
export { TopicsPage as component };
