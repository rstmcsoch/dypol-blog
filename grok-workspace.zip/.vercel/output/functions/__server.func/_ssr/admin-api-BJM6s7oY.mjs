import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BcXUIxxS.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-api-BJM6s7oY.js
async function guard() {
	const { requireAdmin } = await import("./admin.server-iBYOXHvi.mjs");
	return requireAdmin();
}
var adminSession_createServerFn_handler = createServerRpc({
	id: "311203de7aef544ce24460d22b334279d4049e6d3dd189cc93ea9d0eab49421d",
	name: "adminSession",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSession.__executeServer(opts));
var adminSession = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminSession_createServerFn_handler, async () => {
	const admin = await guard();
	const { listGrants } = await import("./admin.server-iBYOXHvi.mjs");
	return {
		email: admin.email,
		mode: admin.mode,
		grants: admin.mode === "account" ? await listGrants() : []
	};
});
var adminDashboard_createServerFn_handler = createServerRpc({
	id: "29f05c5b8dc87acf90b5097510acfe0651c59a61c4c1d24018d4477921a0e3b3",
	name: "adminDashboard",
	filename: "src/content/admin-api.ts"
}, (opts) => adminDashboard.__executeServer(opts));
var adminDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminDashboard_createServerFn_handler, async () => {
	await guard();
	const { adminOverview } = await import("./repository.server-CPUCf2d_.mjs");
	return adminOverview();
});
var adminArticles_createServerFn_handler = createServerRpc({
	id: "b2e4dc5de5416346554155373b926e041e3b705169d27aedd43386150a7b3922",
	name: "adminArticles",
	filename: "src/content/admin-api.ts"
}, (opts) => adminArticles.__executeServer(opts));
var adminArticles = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminArticles_createServerFn_handler, async ({ data }) => {
	await guard();
	const { adminList } = await import("./repository.server-CPUCf2d_.mjs");
	const { articleListSchema } = await import("./validate-CVEpBKuy.mjs").then((n) => n.u).then((n) => n.c);
	return adminList(articleListSchema.parse(data));
});
var adminEditorData_createServerFn_handler = createServerRpc({
	id: "7adc6ccf79204a7d94cde8e6cdc151106fe229e332e25f15193b325ee6554978",
	name: "adminEditorData",
	filename: "src/content/admin-api.ts"
}, (opts) => adminEditorData.__executeServer(opts));
var adminEditorData = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(adminEditorData_createServerFn_handler, async ({ data }) => {
	await guard();
	const { adminEditor } = await import("./repository.server-CPUCf2d_.mjs");
	return adminEditor(data.id);
});
var adminSaveArticle_createServerFn_handler = createServerRpc({
	id: "b5a092748e32350c89dc51ac3990f3d66f2f02314b11082b96d304a71794ae93",
	name: "adminSaveArticle",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSaveArticle.__executeServer(opts));
var adminSaveArticle = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveArticle_createServerFn_handler, async ({ data }) => {
	await guard();
	const { saveArticle } = await import("./repository.server-CPUCf2d_.mjs");
	return saveArticle(data);
});
var adminDeleteDraft_createServerFn_handler = createServerRpc({
	id: "6d0057c91825de919bad81961252846f8e7c06ca04c0147fe819835edba3f116",
	name: "adminDeleteDraft",
	filename: "src/content/admin-api.ts"
}, (opts) => adminDeleteDraft.__executeServer(opts));
var adminDeleteDraft = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminDeleteDraft_createServerFn_handler, async ({ data }) => {
	await guard();
	const { deleteDraft } = await import("./repository.server-CPUCf2d_.mjs");
	await deleteDraft(data.id);
	return { ok: true };
});
var adminPreview_createServerFn_handler = createServerRpc({
	id: "77d192b23dd9b0fea92fcf9a8efcdffcab9ebf4a5a262c3b72891a7f38d616ad",
	name: "adminPreview",
	filename: "src/content/admin-api.ts"
}, (opts) => adminPreview.__executeServer(opts));
var adminPreview = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(adminPreview_createServerFn_handler, async ({ data }) => {
	await guard();
	const { readPreview, readShell } = await import("./repository.server-CPUCf2d_.mjs");
	const preview = await readPreview(data.id);
	const shell = await readShell();
	return preview ? {
		...preview,
		site: shell.site
	} : null;
});
var adminTaxonomy_createServerFn_handler = createServerRpc({
	id: "03f791df99c3a5ff76f1fe361b85d1c138dc7b582e2d830c1eeb0bc1b8ff8626",
	name: "adminTaxonomy",
	filename: "src/content/admin-api.ts"
}, (opts) => adminTaxonomy.__executeServer(opts));
var adminTaxonomy = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminTaxonomy_createServerFn_handler, async () => {
	await guard();
	const { adminList } = await import("./repository.server-CPUCf2d_.mjs");
	const list = await adminList({});
	return {
		categories: list.categories,
		tags: list.tags,
		articles: list.articles
	};
});
var adminSaveCategory_createServerFn_handler = createServerRpc({
	id: "44ad5d1a35b6729c6a5303d2370a6e25b431a3d0198cf3157c8290694150c1a1",
	name: "adminSaveCategory",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSaveCategory.__executeServer(opts));
var adminSaveCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveCategory_createServerFn_handler, async ({ data }) => {
	await guard();
	const { saveCategory } = await import("./repository.server-CPUCf2d_.mjs");
	return saveCategory(data);
});
var adminDeleteCategory_createServerFn_handler = createServerRpc({
	id: "babe7734ada0891362a3d78d148ff56cf225ed42d8172506cd95314f8a0b3b4d",
	name: "adminDeleteCategory",
	filename: "src/content/admin-api.ts"
}, (opts) => adminDeleteCategory.__executeServer(opts));
var adminDeleteCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminDeleteCategory_createServerFn_handler, async ({ data }) => {
	await guard();
	const { deleteCategory } = await import("./repository.server-CPUCf2d_.mjs");
	await deleteCategory(data.id);
	return { ok: true };
});
var adminSaveTag_createServerFn_handler = createServerRpc({
	id: "3eaecc75ac0348691dd6df2543dce97064fad3b9df1f135661674cbd48d4a101",
	name: "adminSaveTag",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSaveTag.__executeServer(opts));
var adminSaveTag = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveTag_createServerFn_handler, async ({ data }) => {
	await guard();
	const { saveTag } = await import("./repository.server-CPUCf2d_.mjs");
	return saveTag(data);
});
var adminDeleteTag_createServerFn_handler = createServerRpc({
	id: "618452f3e1d2d2a1057f521cb8d2eba3754d81dffb39a262a7fa47b9a3b7db96",
	name: "adminDeleteTag",
	filename: "src/content/admin-api.ts"
}, (opts) => adminDeleteTag.__executeServer(opts));
var adminDeleteTag = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminDeleteTag_createServerFn_handler, async ({ data }) => {
	await guard();
	const { deleteTag } = await import("./repository.server-CPUCf2d_.mjs");
	await deleteTag(data.id);
	return { ok: true };
});
var adminSettings_createServerFn_handler = createServerRpc({
	id: "c2e69cc548f8603d970ccb6cdc4916d12fa99cc924bee98ea6ee56def86a8a4f",
	name: "adminSettings",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSettings.__executeServer(opts));
var adminSettings = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminSettings_createServerFn_handler, async () => {
	const session = await guard();
	const { readSettings, listMedia } = await import("./repository.server-CPUCf2d_.mjs");
	const { listGrants } = await import("./admin.server-iBYOXHvi.mjs");
	const { MediaBindingError } = await import("./media-store.server-B9cUOc91.mjs");
	const settings = await readSettings();
	let media = [];
	let mediaNotice = null;
	try {
		media = await listMedia();
	} catch (error) {
		if (!(error instanceof MediaBindingError)) throw error;
		mediaNotice = error.message;
	}
	return {
		...settings,
		media,
		mediaNotice,
		mode: session.mode,
		email: session.email,
		grants: await listGrants()
	};
});
var adminSaveSettings_createServerFn_handler = createServerRpc({
	id: "0152dde4a155ff16f55285e3698dfd9bc08dd4cacfb344def6061b51f1a6d987",
	name: "adminSaveSettings",
	filename: "src/content/admin-api.ts"
}, (opts) => adminSaveSettings.__executeServer(opts));
var adminSaveSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminSaveSettings_createServerFn_handler, async ({ data }) => {
	await guard();
	const { saveSettings } = await import("./repository.server-CPUCf2d_.mjs");
	await saveSettings(data);
	return { ok: true };
});
var adminMedia_createServerFn_handler = createServerRpc({
	id: "6f51ddcfee1d42b96594045f399ad3da324f95fde5eb0c4e111d48c40695e04b",
	name: "adminMedia",
	filename: "src/content/admin-api.ts"
}, (opts) => adminMedia.__executeServer(opts));
var adminMedia = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(adminMedia_createServerFn_handler, async () => {
	await guard();
	const { listMedia } = await import("./repository.server-CPUCf2d_.mjs");
	const { MediaBindingError } = await import("./media-store.server-B9cUOc91.mjs");
	try {
		return {
			media: await listMedia(),
			notice: null
		};
	} catch (error) {
		if (error instanceof MediaBindingError) return {
			media: [],
			notice: error.message
		};
		throw error;
	}
});
var adminUploadMedia_createServerFn_handler = createServerRpc({
	id: "c9b2131931c07d8010e03644275e0217c3ac15279370a5fc6b460fd5d7c03921",
	name: "adminUploadMedia",
	filename: "src/content/admin-api.ts"
}, (opts) => adminUploadMedia.__executeServer(opts));
var adminUploadMedia = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminUploadMedia_createServerFn_handler, async ({ data }) => {
	await guard();
	const { uploadMedia } = await import("./repository.server-CPUCf2d_.mjs");
	return uploadMedia(data);
});
var adminDeleteMedia_createServerFn_handler = createServerRpc({
	id: "b155a1b2b58bb08fdce672cee148c07f46796a2bb63c841e1c84d93c56b49e59",
	name: "adminDeleteMedia",
	filename: "src/content/admin-api.ts"
}, (opts) => adminDeleteMedia.__executeServer(opts));
var adminDeleteMedia = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminDeleteMedia_createServerFn_handler, async ({ data }) => {
	await guard();
	const { deleteMedia } = await import("./repository.server-CPUCf2d_.mjs");
	await deleteMedia(data.id);
	return { ok: true };
});
var adminAddGrant_createServerFn_handler = createServerRpc({
	id: "3a3c59c60a99609a8817af5c6fa5b0d38b21a0d1ed81c72797030919dd2fdbc8",
	name: "adminAddGrant",
	filename: "src/content/admin-api.ts"
}, (opts) => adminAddGrant.__executeServer(opts));
var adminAddGrant = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminAddGrant_createServerFn_handler, async ({ data }) => {
	await guard();
	const { addGrant } = await import("./admin.server-iBYOXHvi.mjs");
	await addGrant(data.email);
	return { ok: true };
});
var adminRemoveGrant_createServerFn_handler = createServerRpc({
	id: "62449b4b831c8a1db5cdff46cf1aaf3b9d97d3af64526a34c3e31f1175a0f75d",
	name: "adminRemoveGrant",
	filename: "src/content/admin-api.ts"
}, (opts) => adminRemoveGrant.__executeServer(opts));
var adminRemoveGrant = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(adminRemoveGrant_createServerFn_handler, async ({ data }) => {
	await guard();
	const { removeGrant } = await import("./admin.server-iBYOXHvi.mjs");
	await removeGrant(data.email);
	return { ok: true };
});
//#endregion
export { adminAddGrant_createServerFn_handler, adminArticles_createServerFn_handler, adminDashboard_createServerFn_handler, adminDeleteCategory_createServerFn_handler, adminDeleteDraft_createServerFn_handler, adminDeleteMedia_createServerFn_handler, adminDeleteTag_createServerFn_handler, adminEditorData_createServerFn_handler, adminMedia_createServerFn_handler, adminPreview_createServerFn_handler, adminRemoveGrant_createServerFn_handler, adminSaveArticle_createServerFn_handler, adminSaveCategory_createServerFn_handler, adminSaveSettings_createServerFn_handler, adminSaveTag_createServerFn_handler, adminSession_createServerFn_handler, adminSettings_createServerFn_handler, adminTaxonomy_createServerFn_handler, adminUploadMedia_createServerFn_handler };
