import { o as __toESM } from "../_runtime.mjs";
import { n as site, t as publicationStatuses } from "./types-BLz7yWjW.mjs";
import { $ as notFound, S as Link, T as require_jsx_runtime, X as redirect, _ as Outlet, b as createRootRoute, d as Scripts, et as require_react, f as HeadContent, g as createRouter, p as useRouterState, v as lazyRouteComponent, w as useRouter, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as useTrending, t as useSite } from "./use-site-ChaMm9lO.mjs";
import { a as getServerFnById, c as __exportAll, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BcXUIxxS.mjs";
import { _n as object, bn as string, gn as number, mn as literal, xn as union } from "../_libs/@better-auth/core+[...].mjs";
import { n as Moon, t as Sun } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/states-XhyJe38a.js
var import_jsx_runtime = require_jsx_runtime();
function EmptyState() {
	const site = useSite();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "state-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "state-panel__num",
				children: "00"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "state-panel__title",
				children: site.labels.emptyTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "state-panel__body",
				children: site.labels.emptyBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/articles",
				className: "btn btn--ghost",
				children: site.labels.emptyAction
			})
		]
	});
}
function NotFoundState() {
	const site = useSite();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "state-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.notFoundKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "state-panel__title",
						children: site.labels.notFoundTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "state-panel__body",
						children: site.labels.notFoundBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "btn",
						children: site.labels.backHome
					})
				]
			})
		})
	});
}
function PagePending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		"aria-busy": "true",
		"aria-live": "polite",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: site.labels.loading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton skeleton--title" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton skeleton--short" })
			]
		})
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-B2Izd0c7.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/public-api-DiYO81Tx.js
var getShell = createServerFn({ method: "GET" }).handler(createSsrRpc("fc99ab95133833eb0ea69a8a7e2f9850423cad4c95783ff5b3cd5b9599999cc2"));
var getHome = createServerFn({ method: "GET" }).handler(createSsrRpc("c929b3050df5d7a139d35d884f0563df3c3ac12bb2165543068a44ad310b8852"));
var getIndex = createServerFn({ method: "GET" }).handler(createSsrRpc("05cf9a147c098d3bf756ea510a2efb97c67a729890ae602b753d90a0c6376ead"));
var getTopics = createServerFn({ method: "GET" }).handler(createSsrRpc("4c57f20ab77e1f917bddd3b427e4d24a36c1140056cc89eb78339f79e91b7696"));
var getTopic = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("640625f4ae5008bd82663e12856f05671de96f500f4539b8d949a75536d950e3"));
var getArticle = createServerFn({ method: "GET" }).validator((input) => input).handler(createSsrRpc("bd485879f4b630eb62e50301bec6c8cd1b20ca64c23dc0a4741ade678b061d41"));
createServerFn({ method: "GET" }).handler(createSsrRpc("14f3bdd9f7a7dd3234f0eb574fc4be18e277abe5ca5449d21c321735d434cc83"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/admin-api-DDn3yWXf.js
var adminSession = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("311203de7aef544ce24460d22b334279d4049e6d3dd189cc93ea9d0eab49421d"));
var adminDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("29f05c5b8dc87acf90b5097510acfe0651c59a61c4c1d24018d4477921a0e3b3"));
var adminArticles = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("b2e4dc5de5416346554155373b926e041e3b705169d27aedd43386150a7b3922"));
var adminEditorData = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("7adc6ccf79204a7d94cde8e6cdc151106fe229e332e25f15193b325ee6554978"));
var adminSaveArticle = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("b5a092748e32350c89dc51ac3990f3d66f2f02314b11082b96d304a71794ae93"));
var adminDeleteDraft = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("6d0057c91825de919bad81961252846f8e7c06ca04c0147fe819835edba3f116"));
var adminPreview = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("77d192b23dd9b0fea92fcf9a8efcdffcab9ebf4a5a262c3b72891a7f38d616ad"));
var adminTaxonomy = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("03f791df99c3a5ff76f1fe361b85d1c138dc7b582e2d830c1eeb0bc1b8ff8626"));
var adminSaveCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("44ad5d1a35b6729c6a5303d2370a6e25b431a3d0198cf3157c8290694150c1a1"));
var adminDeleteCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("babe7734ada0891362a3d78d148ff56cf225ed42d8172506cd95314f8a0b3b4d"));
var adminSaveTag = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("3eaecc75ac0348691dd6df2543dce97064fad3b9df1f135661674cbd48d4a101"));
var adminDeleteTag = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("618452f3e1d2d2a1057f521cb8d2eba3754d81dffb39a262a7fa47b9a3b7db96"));
var adminSettings = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c2e69cc548f8603d970ccb6cdc4916d12fa99cc924bee98ea6ee56def86a8a4f"));
var adminSaveSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0152dde4a155ff16f55285e3698dfd9bc08dd4cacfb344def6061b51f1a6d987"));
var adminMedia = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("6f51ddcfee1d42b96594045f399ad3da324f95fde5eb0c4e111d48c40695e04b"));
var adminUploadMedia = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("c9b2131931c07d8010e03644275e0217c3ac15279370a5fc6b460fd5d7c03921"));
var adminDeleteMedia = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("b155a1b2b58bb08fdce672cee148c07f46796a2bb63c841e1c84d93c56b49e59"));
var adminAddGrant = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("3a3c59c60a99609a8817af5c6fa5b0d38b21a0d1ed81c72797030919dd2fdbc8"));
var adminRemoveGrant = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("62449b4b831c8a1db5cdff46cf1aaf3b9d97d3af64526a34c3e31f1175a0f75d"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/gate-j77Od0KV.js
async function requireDesk() {
	try {
		return await adminSession();
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		if (message.includes("Forbidden")) throw redirect({
			to: "/login",
			search: { denied: true }
		});
		if (message.includes("Unauthorized")) throw redirect({
			to: "/login",
			search: { denied: false }
		});
		throw error;
	}
}
function errorText(error) {
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong.";
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-wjzIUxJ1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "error-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "state-panel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "state-panel__title",
					children: site.labels.errorTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: errorMessage(error) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn",
					href: "/",
					children: site.labels.errorHome
				})
			]
		})
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function NavLink({ href, className, children }) {
	const activeProps = { className: "is-active" };
	if (href === "/") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className,
		activeOptions: { exact: true },
		activeProps,
		children
	});
	if (href === "/articles") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/articles",
		className,
		activeOptions: { exact: false },
		activeProps,
		children
	});
	if (href === "/topics") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/topics",
		className,
		activeOptions: { exact: false },
		activeProps,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/about",
		className,
		activeProps,
		children
	});
}
function SiteFooter() {
	const site = useSite();
	const links = site.nav.filter((item) => item.visible);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container footer-grid",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "footer-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "footer-mark",
						children: "DYPOL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "footer-note",
						children: site.description
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "footer-nav",
					"aria-label": site.labels.footerNav,
					children: [links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						href: item.href,
						className: "footer-link",
						children: item.label
					}, item.id)), site.footer.links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						className: "footer-link",
						children: item.label
					}, item.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "footer-sign",
					children: site.footer.note
				})
			]
		})
	});
}
var THEME_KEY = "dypol-theme";
var themeBootScript = `(function(){try{var s=localStorage.getItem("${THEME_KEY}");var t=s==="light"||s==="dark"?s:(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");document.documentElement.setAttribute("data-theme",t);}catch(e){document.documentElement.setAttribute("data-theme","light");}})();`;
function readTheme() {
	const set = document.documentElement.dataset.theme;
	if (set === "light" || set === "dark") return set;
	return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function applyTheme(next, persist) {
	document.documentElement.dataset.theme = next;
	if (!persist) return;
	try {
		localStorage.setItem(THEME_KEY, next);
	} catch {}
}
function ThemeToggle() {
	const site = useSite();
	const [theme, setTheme] = (0, import_react.useState)(null);
	(0, import_react.useLayoutEffect)(() => {
		setTheme(readTheme());
	}, []);
	function choose(next) {
		applyTheme(next, true);
		setTheme(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "theme-switch",
		role: "group",
		"aria-label": site.labels.themeGroup,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "theme-switch__btn",
			"data-value": "light",
			"aria-label": site.labels.dayTheme,
			"aria-pressed": theme === null ? void 0 : theme === "light",
			onClick: () => choose("light"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
					"aria-hidden": "true",
					strokeWidth: 2.25
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__label",
					children: site.labels.day
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__mark",
					"aria-hidden": "true"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "theme-switch__btn",
			"data-value": "dark",
			"aria-label": site.labels.nightTheme,
			"aria-pressed": theme === null ? void 0 : theme === "dark",
			onClick: () => choose("dark"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
					"aria-hidden": "true",
					strokeWidth: 2.25
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__label",
					children: site.labels.night
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__mark",
					"aria-hidden": "true"
				})
			]
		})]
	});
}
function SiteHeader() {
	const site = useSite();
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "site-header",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container bar",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavLink, {
					href: "/",
					className: "wordmark",
					children: [
						site.logoMediaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							className: "wordmark__logo",
							src: `/media/${site.logoMediaId}`,
							alt: ""
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "wordmark__name",
							children: "DYPOL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "wordmark__stamp",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grain-layer",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Blog" })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					id: "site-nav",
					className: open ? "site-nav is-open" : "site-nav",
					"aria-label": site.labels.primaryNav,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "site-nav__inner",
						children: site.nav.filter((item) => item.visible).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
							href: item.href,
							className: "nav-link",
							children: item.label
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bar-tools",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "menu-btn",
						"aria-expanded": open,
						"aria-controls": "site-nav",
						onClick: () => setOpen((value) => !value),
						children: open ? site.labels.close : site.labels.menu
					})]
				})
			]
		})
	});
}
/** Re-apply the boot script's choice after hydration, in case the attribute was reset. */
function ThemeSync() {
	(0, import_react.useLayoutEffect)(() => {
		let stored = null;
		try {
			stored = localStorage.getItem(THEME_KEY);
		} catch {
			stored = null;
		}
		if (stored === "light" || stored === "dark") {
			applyTheme(stored, false);
			return;
		}
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		const sync = () => {
			let stored = null;
			try {
				stored = localStorage.getItem(THEME_KEY);
			} catch {
				stored = null;
			}
			if (stored === "light" || stored === "dark") return;
			applyTheme(media.matches ? "dark" : "light", false);
		};
		sync();
		media.addEventListener("change", sync);
		return () => media.removeEventListener("change", sync);
	}, []);
	return null;
}
function TrendingBar() {
	const site = useSite();
	const items = useTrending();
	if (!site.trending.enabled || items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "trend",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container trend__row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "trend__label",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grain-layer",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: site.trending.label })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "trend__list",
				children: items.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/articles/$slug",
					params: { slug: article.slug },
					className: "trend__link",
					children: article.title
				}) }, article.id))
			})]
		})
	});
}
var styles_default = "/assets/styles-CBlGlTJl.css";
var Route$20 = createRootRoute({
	loader: () => getShell(),
	head: ({ loaderData }) => {
		const current = loaderData?.site ?? site;
		return {
			meta: [
				{ charSet: "utf-8" },
				{
					name: "viewport",
					content: "width=device-width, initial-scale=1"
				},
				{ title: current.title },
				{
					name: "description",
					content: current.description
				},
				{
					name: "theme-color",
					content: "#111111"
				},
				{
					name: "robots",
					content: "index, follow"
				}
			],
			links: [
				{
					rel: "icon",
					type: "image/svg+xml",
					href: current.faviconMediaId ? `/media/${current.faviconMediaId}` : "/favicon.svg"
				},
				{
					rel: "stylesheet",
					href: styles_default
				},
				{
					rel: "manifest",
					href: "/__grok/manifest.webmanifest"
				},
				{
					rel: "apple-touch-icon",
					href: "/__grok/icon-180.png"
				}
			]
		};
	},
	shellComponent: RootShell,
	component: RootLayout,
	notFoundComponent: NotFoundState
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: themeBootScript } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function RootLayout() {
	const site = useSite();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	if (pathname === "/admin" || pathname.startsWith("/admin/")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "skip",
				href: "#content",
				children: site.labels.skip
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSync, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var $$splitComponentImporter$16 = () => import("./routes-D8dBzvlk.mjs");
var Route$19 = createFileRoute("/")({
	loader: () => getHome(),
	head: () => ({
		meta: [{ title: site.title }, {
			name: "description",
			content: site.description
		}],
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("../_-ClwaIRTe.mjs");
var $$splitNotFoundComponentImporter$2 = () => import("../_-CaHTq9F1.mjs");
var Route$18 = createFileRoute("/$")({
	loader: () => {
		throw notFound();
	},
	head: () => ({ meta: [{ title: `${site.labels.notFoundKicker} — ${site.name}` }, {
		name: "robots",
		content: "noindex"
	}] }),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$2, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./about-BuMI8hpq.mjs");
var Route$17 = createFileRoute("/about")({
	head: () => ({
		meta: [{ title: "About — DYPOL Blog" }, {
			name: "description",
			content: "DYPOL Blog is the public journal of DYPOL Labs."
		}],
		links: [{
			rel: "canonical",
			href: "/about"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./admin-D2gb1SML.mjs");
var Route$16 = createFileRoute("/admin")({
	loader: () => requireDesk(),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./login-9WPDEtPi.mjs");
var Route$15 = createFileRoute("/login")({
	validateSearch: (search) => ({ denied: search.denied === true || search.denied === "true" || search.denied === "1" }),
	head: () => ({ meta: [{ title: "Desk — DYPOL Blog" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var Route$14 = createFileRoute("/robots.txt")({ server: { handlers: { GET: ({ request }) => {
	const body = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /preview\nSitemap: ${new URL(request.url).origin}/sitemap.xml\n`;
	return new Response(body, { headers: { "content-type": "text/plain; charset=utf-8" } });
} } } });
var Route$13 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async ({ request }) => {
	const { readSitemap } = await import("./repository.server-CPUCf2d_.mjs");
	const entries = await readSitemap();
	const origin = new URL(request.url).origin;
	const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${[
		"/",
		"/articles",
		"/topics",
		"/about",
		...entries.articles.map((slug) => `/articles/${slug}`),
		...entries.topics.map((slug) => `/topics/${slug}`)
	].map((path) => `  <url><loc>${origin}${path}</loc></url>`).join("\n")}
</urlset>
`;
	return new Response(body, { headers: { "content-type": "application/xml; charset=utf-8" } });
} } } });
var $$splitComponentImporter$11 = () => import("./admin-CEeo4y01.mjs");
var Route$12 = createFileRoute("/admin/")({
	loader: () => adminDashboard(),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./media-C21AoKTU.mjs");
var Route$11 = createFileRoute("/admin/media")({
	loader: () => adminMedia(),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./settings-BO2roKeW.mjs");
var Route$10 = createFileRoute("/admin/settings")({
	loader: () => adminSettings(),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./topics-BRXoeZzS.mjs");
var Route$9 = createFileRoute("/admin/topics")({
	loader: () => adminTaxonomy(),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./articles-DGQuQNJc.mjs");
var Route$8 = createFileRoute("/articles/")({
	loader: () => getIndex(),
	head: () => ({
		meta: [{ title: "Index — DYPOL Blog" }, {
			name: "description",
			content: "Every published piece, newest first."
		}],
		links: [{
			rel: "canonical",
			href: "/articles"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("../_slug-B0fcVTlJ.mjs");
var $$splitNotFoundComponentImporter$1 = () => import("../_slug-BuYny6Gd.mjs");
var Route$7 = createFileRoute("/articles/$slug")({
	loader: async ({ params }) => {
		const data = await getArticle({ data: { slug: params.slug } });
		if (!data) throw notFound();
		return data;
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "DYPOL Blog" }] };
		const { article } = loaderData;
		const title = article.seoTitle ?? `${article.title} — DYPOL Blog`;
		const description = article.seoDescription ?? article.excerpt;
		const jsonLd = {
			"@context": "https://schema.org",
			"@type": "BlogPosting",
			headline: article.title,
			description,
			datePublished: article.publishedAt,
			dateModified: article.updatedAt,
			articleSection: loaderData.category?.label,
			publisher: {
				"@type": "Organization",
				name: "DYPOL Labs"
			}
		};
		return {
			meta: [{ title }, {
				name: "description",
				content: description
			}],
			links: [{
				rel: "canonical",
				href: `/articles/${article.slug}`
			}],
			scripts: [{
				type: "application/ld+json",
				children: JSON.stringify(jsonLd)
			}]
		};
	},
	pendingComponent: PagePending,
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$1, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var Route$6 = createFileRoute("/media/$id")({ server: { handlers: { GET: async ({ params }) => {
	const { readMediaFile } = await import("./repository.server-CPUCf2d_.mjs");
	const { MediaBindingError } = await import("./media-store.server-B9cUOc91.mjs");
	try {
		const file = await readMediaFile(params.id);
		if (!file) return new Response("Not found", { status: 404 });
		const body = new Uint8Array(file.bytes.byteLength);
		body.set(file.bytes);
		return new Response(body, { headers: {
			"content-type": file.mime,
			"cache-control": "public, max-age=3600",
			"x-content-type-options": "nosniff"
		} });
	} catch (error) {
		if (error instanceof MediaBindingError) return new Response(error.message, {
			status: 503,
			headers: { "content-type": "text/plain; charset=utf-8" }
		});
		throw error;
	}
} } } });
var $$splitComponentImporter$5 = () => import("../_id-CnQOinov.mjs");
var Route$5 = createFileRoute("/preview/$id")({
	loader: async ({ params }) => {
		try {
			const data = await adminPreview({ data: { id: params.id } });
			if (!data) throw notFound();
			return data;
		} catch (error) {
			const message = error instanceof Error ? error.message : "";
			if (message.includes("Unauthorized") || message.includes("Forbidden")) throw redirect({
				to: "/login",
				search: { denied: message.includes("Forbidden") }
			});
			throw error;
		}
	},
	head: () => ({ meta: [{ title: "Preview — DYPOL Blog" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./topics-CNfuJ7IQ.mjs");
var Route$4 = createFileRoute("/topics/")({
	loader: () => getTopics(),
	head: () => ({
		meta: [{ title: "Topics — DYPOL Blog" }, {
			name: "description",
			content: "Pieces are filed by subject."
		}],
		links: [{
			rel: "canonical",
			href: "/topics"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_slug-BHRA-YRN.mjs");
var $$splitNotFoundComponentImporter = () => import("../_slug-B5qmcP3Q.mjs");
var Route$3 = createFileRoute("/topics/$slug")({
	loader: async ({ params }) => {
		const data = await getTopic({ data: { slug: params.slug } });
		if (!data) throw notFound();
		return data;
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Topics — DYPOL Blog" }] };
		return {
			meta: [{ title: `${loaderData.category.label} — DYPOL Blog` }, {
				name: "description",
				content: loaderData.category.description
			}],
			links: [{
				rel: "canonical",
				href: `/topics/${loaderData.category.slug}`
			}]
		};
	},
	pendingComponent: PagePending,
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./articles-BuhoEgSs.mjs");
var Route$2 = createFileRoute("/admin/articles/")({
	validateSearch: (search) => ({
		q: typeof search.q === "string" && search.q ? search.q : void 0,
		status: publicationStatuses.find((status) => status === search.status),
		categoryId: typeof search.categoryId === "string" && search.categoryId ? search.categoryId : void 0,
		tagId: typeof search.tagId === "string" && search.tagId ? search.tagId : void 0,
		sort: search.sort === "published" || search.sort === "title" || search.sort === "updated" ? search.sort : void 0
	}),
	loaderDeps: ({ search }) => search,
	loader: ({ deps }) => adminArticles({ data: deps }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_id-CEqyKH7G.mjs");
var Route$1 = createFileRoute("/admin/articles/$id")({
	loader: async ({ params }) => {
		const data = await adminEditorData({ data: { id: params.id } });
		if (!data.article) throw notFound();
		return data;
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./new-DorUKGm1.mjs");
var Route = createFileRoute("/admin/articles/new")({
	loader: () => adminEditorData({ data: { id: null } }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$19.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$20
});
var SplatRoute = Route$18.update({
	id: "/$",
	path: "/$",
	getParentRoute: () => Route$20
});
var AboutRoute = Route$17.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$20
});
var AdminRoute = Route$16.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$20
});
var LoginRoute = Route$15.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$20
});
var RobotsDottxtRoute = Route$14.update({
	id: "/robots.txt",
	path: "/robots.txt",
	getParentRoute: () => Route$20
});
var SitemapDotxmlRoute = Route$13.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$20
});
var AdminIndexRoute = Route$12.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminMediaRoute = Route$11.update({
	id: "/media",
	path: "/media",
	getParentRoute: () => AdminRoute
});
var AdminSettingsRoute = Route$10.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AdminRoute
});
var AdminTopicsRoute = Route$9.update({
	id: "/topics",
	path: "/topics",
	getParentRoute: () => AdminRoute
});
var ArticlesIndexRoute = Route$8.update({
	id: "/articles/",
	path: "/articles/",
	getParentRoute: () => Route$20
});
var ArticlesSlugRoute = Route$7.update({
	id: "/articles/$slug",
	path: "/articles/$slug",
	getParentRoute: () => Route$20
});
var MediaIdRoute = Route$6.update({
	id: "/media/$id",
	path: "/media/$id",
	getParentRoute: () => Route$20
});
var PreviewIdRoute = Route$5.update({
	id: "/preview/$id",
	path: "/preview/$id",
	getParentRoute: () => Route$20
});
var TopicsIndexRoute = Route$4.update({
	id: "/topics/",
	path: "/topics/",
	getParentRoute: () => Route$20
});
var TopicsSlugRoute = Route$3.update({
	id: "/topics/$slug",
	path: "/topics/$slug",
	getParentRoute: () => Route$20
});
var AdminArticlesIndexRoute = Route$2.update({
	id: "/articles/",
	path: "/articles/",
	getParentRoute: () => AdminRoute
});
var AdminRouteChildren = {
	AdminMediaRoute,
	AdminSettingsRoute,
	AdminTopicsRoute,
	AdminIndexRoute,
	AdminArticlesIdRoute: Route$1.update({
		id: "/articles/$id",
		path: "/articles/$id",
		getParentRoute: () => AdminRoute
	}),
	AdminArticlesNewRoute: Route.update({
		id: "/articles/new",
		path: "/articles/new",
		getParentRoute: () => AdminRoute
	}),
	AdminArticlesIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	SplatRoute,
	AboutRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	LoginRoute,
	RobotsDottxtRoute,
	SitemapDotxmlRoute,
	ArticlesSlugRoute,
	MediaIdRoute,
	PreviewIdRoute,
	TopicsSlugRoute,
	ArticlesIndexRoute,
	TopicsIndexRoute
};
var routeTree = Route$20._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { NotFoundState as A, adminRemoveGrant as C, adminSaveTag as D, adminSaveSettings as E, adminUploadMedia as O, adminDeleteTag as S, adminSaveCategory as T, errorText as _, Route$3 as a, adminDeleteDraft as b, Route$7 as c, Route$10 as d, Route$11 as f, Route$19 as g, Route$16 as h, Route$2 as i, EmptyState as k, Route$8 as l, Route$15 as m, Route as n, Route$4 as o, Route$12 as p, Route$1 as r, Route$5 as s, router_exports as t, Route$9 as u, adminAddGrant as v, adminSaveArticle as w, adminDeleteMedia as x, adminDeleteCategory as y };
