import { S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as padIndex, t as formatDate } from "./format-BabHa5xU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/index-list-C_IXj46n.js
var import_jsx_runtime = require_jsx_runtime();
function IndexList({ articles, meta, minRead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "index-list",
		children: articles.map((article) => {
			const row = meta[article.id];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/articles/$slug",
				params: { slug: article.slug },
				className: "index-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "index-row__num",
						children: padIndex(row?.rank ?? 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "index-row__main",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "index-row__title",
							children: article.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "index-row__excerpt",
							children: article.excerpt
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "index-row__meta",
						children: [
							row?.categoryLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.categoryLabel }) : null,
							article.publishedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate(article.publishedAt) }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								row?.minutes ?? 1,
								" ",
								minRead
							] })
						]
					})
				]
			}) }, article.id);
		})
	});
}
//#endregion
export { IndexList as t };
