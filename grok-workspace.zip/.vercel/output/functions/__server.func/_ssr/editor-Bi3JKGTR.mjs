import { o as __toESM } from "../_runtime.mjs";
import { C as useNavigate, S as Link, T as require_jsx_runtime, et as require_react, m as useBlocker, w as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as errorText, b as adminDeleteDraft, w as adminSaveArticle } from "./router-wjzIUxJ1.mjs";
import { t as readingMinutes } from "./present-Dcl3727_.mjs";
import { c as slugify } from "./validate-CVEpBKuy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/editor-Bi3JKGTR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var motifs = [
	"corner",
	"band",
	"split",
	"stamp",
	"stack",
	"edge"
];
function toLocal(iso) {
	if (!iso) return "";
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	const pad = (value) => String(value).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function fromLocal(value) {
	if (!value) return null;
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? null : date.toISOString();
}
function fromArticle(article) {
	return {
		id: article.id,
		title: article.title,
		slug: article.slug,
		excerpt: article.excerpt,
		categoryId: article.categoryId,
		tagIds: article.tagIds,
		motif: article.motif,
		featured: article.featured,
		seoTitle: article.seoTitle ?? "",
		seoDescription: article.seoDescription ?? "",
		coverMediaId: article.coverMediaId ?? null,
		publishedAt: toLocal(article.publishedAt),
		blocks: article.blocks,
		status: article.status
	};
}
function blank(categoryId) {
	return {
		id: null,
		title: "",
		slug: "",
		excerpt: "",
		categoryId,
		tagIds: [],
		motif: "corner",
		featured: false,
		seoTitle: "",
		seoDescription: "",
		coverMediaId: null,
		publishedAt: "",
		blocks: [{
			type: "paragraph",
			text: ""
		}],
		status: "draft"
	};
}
function ArticleEditor({ article, categories, tags, media }) {
	const navigate = useNavigate();
	const router = useRouter();
	const [draft, setDraft] = (0, import_react.useState)(() => article ? fromArticle(article) : blank(categories[0]?.id ?? ""));
	const [baseline, setBaseline] = (0, import_react.useState)(() => JSON.stringify(article ? fromArticle(article) : blank(categories[0]?.id ?? "")));
	const [slugTouched, setSlugTouched] = (0, import_react.useState)(Boolean(article));
	const [pending, setPending] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const dirty = JSON.stringify(draft) !== baseline;
	const blocker = useBlocker({
		shouldBlockFn: () => dirty && !pending,
		enableBeforeUnload: () => dirty && !pending,
		withResolver: true
	});
	function update(patch) {
		setDraft((current) => ({
			...current,
			...patch
		}));
	}
	function setTitle(title) {
		setDraft((current) => ({
			...current,
			title,
			slug: slugTouched ? current.slug : slugify(title)
		}));
	}
	function setBlock(index, block) {
		setDraft((current) => ({
			...current,
			blocks: current.blocks.map((item, itemIndex) => itemIndex === index ? block : item)
		}));
	}
	function moveBlock(index, direction) {
		setDraft((current) => {
			const next = [...current.blocks];
			const target = index + direction;
			if (target < 0 || target >= next.length) return current;
			const [item] = next.splice(index, 1);
			if (!item) return current;
			next.splice(target, 0, item);
			return {
				...current,
				blocks: next
			};
		});
	}
	async function commit(intent) {
		setPending(intent);
		setError(null);
		setMessage(null);
		try {
			const saved = await adminSaveArticle({ data: {
				id: draft.id,
				title: draft.title,
				slug: draft.slug,
				excerpt: draft.excerpt,
				categoryId: draft.categoryId,
				tagIds: draft.tagIds,
				motif: draft.motif,
				featured: draft.featured,
				seoTitle: draft.seoTitle,
				seoDescription: draft.seoDescription,
				coverMediaId: draft.coverMediaId,
				publishedAt: fromLocal(draft.publishedAt),
				blocks: draft.blocks,
				intent
			} });
			const next = {
				...draft,
				id: saved.id,
				slug: saved.slug,
				status: saved.status
			};
			setDraft(next);
			setBaseline(JSON.stringify(next));
			setSlugTouched(true);
			setConfirm(null);
			setMessage(intent === "publish" ? "Published." : intent === "unpublish" ? "Unpublished." : "Saved.");
			if (!draft.id) await navigate({
				to: "/admin/articles/$id",
				params: { id: saved.id }
			});
			await router.invalidate();
		} catch (caught) {
			setError(errorText(caught));
		} finally {
			setPending(null);
		}
	}
	async function removeDraft() {
		if (!draft.id) return;
		setPending("delete");
		setError(null);
		try {
			await adminDeleteDraft({ data: { id: draft.id } });
			setBaseline(JSON.stringify(draft));
			await navigate({ to: "/admin/articles" });
		} catch (caught) {
			setError(errorText(caught));
			setPending(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (event) => {
			event.preventDefault();
			commit("save");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "desk-kicker",
				children: draft.status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "desk-title",
				children: draft.title || "New piece"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "desk-note",
				children: [readingMinutes({ blocks: draft.blocks }), " min · the public page uses this same article shape."]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "banner banner--bad",
				role: "alert",
				children: error
			}) : null,
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "banner",
				role: "status",
				children: message
			}) : null,
			blocker.status === "blocked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "banner",
				role: "alert",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Leave without saving?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => blocker.proceed(),
						children: "Leave"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn--ghost",
						onClick: () => blocker.reset(),
						children: "Stay"
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "editor-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.title,
								onChange: (event) => setTitle(event.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Excerpt" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.excerpt,
								onChange: (event) => update({ excerpt: event.target.value })
							})]
						}),
						draft.blocks.map((block, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "block-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", { children: [
									"Block ",
									index + 1,
									" · ",
									block.type
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockFields, {
									block,
									onChange: (next) => setBlock(index, next)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-actions",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "btn btn--ghost",
											onClick: () => moveBlock(index, -1),
											disabled: index === 0,
											children: "Move up"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "btn btn--ghost",
											onClick: () => moveBlock(index, 1),
											disabled: index === draft.blocks.length - 1,
											children: "Move down"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "btn btn--ghost",
											onClick: () => update({ blocks: draft.blocks.filter((_, blockIndex) => blockIndex !== index) }),
											children: "Remove"
										})
									]
								})
							]
						}, index)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Add a block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: "",
								onChange: (event) => {
									const type = event.target.value;
									if (!type) return;
									update({ blocks: [...draft.blocks, emptyBlock(type)] });
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Choose"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "paragraph",
										children: "Paragraph"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "heading",
										children: "Heading"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "list",
										children: "List"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "quote",
										children: "Quote"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "code",
										children: "Code"
									})
								]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stack",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.slug,
								onChange: (event) => {
									setSlugTouched(true);
									update({ slug: event.target.value });
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Topic" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.categoryId,
								onChange: (event) => update({ categoryId: event.target.value }),
								children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: category.id,
									children: category.label
								}, category.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "block-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { children: "Tags" }), tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "check-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: draft.tagIds.includes(tag.id),
									onChange: (event) => {
										update({ tagIds: event.target.checked ? [...draft.tagIds, tag.id] : draft.tagIds.filter((id) => id !== tag.id) });
									}
								}), tag.label]
							}, tag.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Plate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.motif,
								onChange: (event) => update({ motif: event.target.value }),
								children: motifs.map((motif) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: motif,
									children: motif
								}, motif))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cover image" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: draft.coverMediaId ?? "",
								onChange: (event) => update({ coverMediaId: event.target.value || null }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Geometric plate"
								}), media.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.filename
								}, item.id))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "check-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: draft.featured,
								onChange: (event) => update({ featured: event.target.checked })
							}), "Featured on the homepage"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Publication date" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "datetime-local",
								value: draft.publishedAt,
								onChange: (event) => update({ publishedAt: event.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SEO title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.seoTitle,
								onChange: (event) => update({ seoTitle: event.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SEO description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.seoDescription,
								onChange: (event) => update({ seoDescription: event.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								type: "submit",
								disabled: Boolean(pending),
								children: pending === "save" ? "Saving…" : "Save"
							}), draft.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/preview/$id",
								params: { id: draft.id },
								className: "btn btn--ghost",
								children: "Preview"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "desk-note",
								children: "Save once to preview."
							})]
						}),
						confirm === "publish" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "banner",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Publish this piece to the public journal?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn",
									disabled: Boolean(pending),
									onClick: () => void commit("publish"),
									children: pending === "publish" ? "Publishing…" : "Publish"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn--ghost",
									onClick: () => setConfirm(null),
									children: "Cancel"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => setConfirm("publish"),
							children: "Publish"
						}),
						draft.status === "published" ? confirm === "unpublish" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "banner",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Take this piece off the public journal?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn",
									disabled: Boolean(pending),
									onClick: () => void commit("unpublish"),
									children: "Unpublish"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn--ghost",
									onClick: () => setConfirm(null),
									children: "Cancel"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn--ghost",
							onClick: () => setConfirm("unpublish"),
							children: "Unpublish"
						}) : null,
						draft.id && draft.status !== "published" ? confirm === "delete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "banner banner--bad",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Delete this ",
								draft.status,
								" piece? This cannot be undone."
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn",
									disabled: Boolean(pending),
									onClick: () => void removeDraft(),
									children: pending === "delete" ? "Deleting…" : "Delete"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn--ghost",
									onClick: () => setConfirm(null),
									children: "Cancel"
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn--ghost",
							onClick: () => setConfirm("delete"),
							children: "Delete"
						}) : null
					]
				})]
			})
		]
	});
}
function emptyBlock(type) {
	if (type === "heading") return {
		type: "heading",
		level: 2,
		text: ""
	};
	if (type === "list") return {
		type: "list",
		items: [""]
	};
	if (type === "quote") return {
		type: "quote",
		text: ""
	};
	if (type === "code") return {
		type: "code",
		code: ""
	};
	return {
		type: "paragraph",
		text: ""
	};
}
function BlockFields({ block, onChange }) {
	if (block.type === "heading") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Level" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			value: block.level,
			onChange: (event) => onChange({
				...block,
				level: Number(event.target.value) === 3 ? 3 : 2
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: 2,
				children: "Heading 2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: 3,
				children: "Heading 3"
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Text" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: block.text,
			onChange: (event) => onChange({
				...block,
				text: event.target.value
			})
		})]
	})] });
	if (block.type === "list") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "check-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked: Boolean(block.ordered),
			onChange: (event) => onChange({
				...block,
				ordered: event.target.checked
			})
		}), "Numbered"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Items, one per line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: block.items.join("\n"),
			onChange: (event) => onChange({
				...block,
				items: event.target.value.split("\n")
			})
		})]
	})] });
	if (block.type === "quote") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quote" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: block.text,
			onChange: (event) => onChange({
				...block,
				text: event.target.value
			})
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Attribution" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: block.attribution ?? "",
			onChange: (event) => onChange({
				...block,
				attribution: event.target.value
			})
		})]
	})] });
	if (block.type === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Language" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: block.language ?? "",
			onChange: (event) => onChange({
				...block,
				language: event.target.value
			})
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: block.code,
			onChange: (event) => onChange({
				...block,
				code: event.target.value
			})
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Paragraph" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: block.text,
			onChange: (event) => onChange({
				...block,
				text: event.target.value
			})
		})]
	});
}
//#endregion
export { ArticleEditor as t };
