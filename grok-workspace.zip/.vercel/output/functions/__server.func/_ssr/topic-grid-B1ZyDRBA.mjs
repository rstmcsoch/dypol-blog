import { S as Link, T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as padIndex } from "./format-BabHa5xU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topic-grid-B1ZyDRBA.js
var import_jsx_runtime = require_jsx_runtime();
function TopicGrid({ topics }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "topic-grid",
		children: topics.map(({ category, count }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/topics/$slug",
			params: { slug: category.slug },
			className: "topic-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "topic-card__count",
					children: padIndex(count)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "topic-card__label",
					children: category.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "topic-card__desc",
					children: category.description
				})
			]
		}) }, category.id))
	});
}
//#endregion
export { TopicGrid as t };
