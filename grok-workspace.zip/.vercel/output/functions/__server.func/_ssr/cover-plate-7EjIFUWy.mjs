import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cover-plate-7EjIFUWy.js
var import_jsx_runtime = require_jsx_runtime();
function CoverPlate({ motif, index, category }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "plate",
		"data-motif": motif,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "plate__ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "grain-layer" })
			}),
			motif === "stack" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "plate__ink plate__ink--2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "grain-layer" })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "plate__cat",
				children: category
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "plate__num",
				children: index
			})
		]
	});
}
//#endregion
export { CoverPlate as t };
