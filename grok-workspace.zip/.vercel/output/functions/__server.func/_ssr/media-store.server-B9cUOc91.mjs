//#region node_modules/.nitro/vite/services/ssr/assets/media-store.server-B9cUOc91.js
/**
* Journal images use the bindings already declared in cloudflare.config.ts:
*   MEDIA — R2 bucket dypol-blog-media (object bytes)
*   DB    — D1 database dypol-blog-db (filename, alt, mime, size, key)
*
* There is no second bucket, no local file store, and no image blob column.
* Postgres keeps references only (cover, logo, favicon).
*/
var MEDIA_BUCKET_NAME = "dypol-blog-media";
var D1_DATABASE_NAME = "dypol-blog-db";
var D1_DATABASE_ID = "78708341-8467-4140-bfa7-0531f14a7aee";
var MediaBindingError = class extends Error {
	constructor() {
		super(`The MEDIA R2 binding is not available in this runtime. Image files belong in the ${MEDIA_BUCKET_NAME} bucket, and their records belong in D1 (${D1_DATABASE_NAME}, ${D1_DATABASE_ID}).`);
		this.name = "MediaBindingError";
	}
};
function mediaObjectKey(id) {
	if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) throw new Error("Media id is not a stable key.");
	return `media/${id}`;
}
function rowToItem(row) {
	return {
		id: row.id,
		filename: row.filename,
		mime: row.mime,
		alt: row.alt,
		bytes: Number(row.byte_size),
		createdAt: row.created_at
	};
}
var ENSURE_MEDIA_TABLE = `create table if not exists media (
  id text primary key,
  object_key text not null unique,
  filename text not null,
  mime text not null,
  alt text not null default '',
  byte_size integer not null,
  created_at text not null
)`;
function createMediaStore(bucket, db) {
	const ready = db.run(ENSURE_MEDIA_TABLE).catch((error) => {
		throw error;
	});
	return {
		ready,
		async list() {
			await ready;
			return (await db.all("select id, object_key, filename, mime, alt, byte_size, created_at from media order by created_at desc")).map(rowToItem);
		},
		async stats() {
			await ready;
			const rows = await db.all("select count(*) as files, coalesce(sum(byte_size), 0) as bytes from media");
			return {
				files: Number(rows[0]?.files ?? 0),
				bytes: Number(rows[0]?.bytes ?? 0)
			};
		},
		async exists(id) {
			await ready;
			return (await db.all("select id from media where id = ?", [id])).length > 0;
		},
		async put(input) {
			await ready;
			const key = mediaObjectKey(input.id);
			await bucket.put(key, input.bytes, input.mime);
			try {
				await db.run("insert into media (id, object_key, filename, mime, alt, byte_size, created_at) values (?, ?, ?, ?, ?, ?, ?)", [
					input.id,
					key,
					input.filename,
					input.mime,
					input.alt,
					input.bytes.byteLength,
					input.createdAt
				]);
			} catch (error) {
				await bucket.delete(key).catch(() => void 0);
				throw error;
			}
		},
		async read(id) {
			await ready;
			const row = (await db.all("select id, object_key, filename, mime, alt, byte_size, created_at from media where id = ?", [id]))[0];
			if (!row) return null;
			const object = await bucket.get(row.object_key);
			if (!object) return null;
			return {
				mime: object.contentType || row.mime,
				bytes: object.bytes
			};
		},
		async remove(id) {
			await ready;
			const row = (await db.all("select object_key from media where id = ?", [id]))[0];
			if (!row) return false;
			await bucket.delete(row.object_key);
			await db.run("delete from media where id = ?", [id]);
			return true;
		}
	};
}
function isBucket(value) {
	if (!value || typeof value !== "object") return false;
	const bucket = value;
	return typeof bucket.put === "function" && typeof bucket.get === "function" && typeof bucket.delete === "function";
}
function isDatabase(value) {
	if (!value || typeof value !== "object") return false;
	return typeof value.prepare === "function";
}
function envFrom(scope) {
	if (!scope || typeof scope !== "object") return null;
	const record = scope;
	if (!isBucket(record.MEDIA) || !isDatabase(record.DB)) return null;
	return {
		MEDIA: record.MEDIA,
		DB: record.DB
	};
}
/**
* The worker injects bindings on `cloudflare:workers` (`env.MEDIA`, `env.DB`).
* Outside that runtime, the same MEDIA bucket and DB database are opened from
* the declaration in cloudflare.config.ts. No other store is consulted.
*/
async function readMediaBindings() {
	const root = globalThis;
	const scopes = [
		root.__env__,
		root.env,
		root
	];
	try {
		const mod = await import(
			/* @vite-ignore */
			["cloudflare", "workers"].join(":")
);
		scopes.unshift(mod.env);
	} catch {}
	for (const scope of scopes) {
		const env = envFrom(scope);
		if (env) return env;
	}
	if (typeof navigator !== "undefined" && navigator.userAgent === "Cloudflare-Workers") return null;
	if (process.env.NODE_TEST_CONTEXT && process.env.DYPOL_MEDIA_PLATFORM !== "on") return null;
	try {
		const { openDeclaredBindings } = await import("./media-platform.server-RVLrHgbL.mjs");
		return await openDeclaredBindings();
	} catch (error) {
		console.error("[media] The MEDIA and DB bindings could not be opened.", error);
		return null;
	}
}
function wrapBucket(binding) {
	return {
		async put(key, bytes, contentType) {
			const body = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength ? bytes : bytes.slice();
			await binding.put(key, body, { httpMetadata: { contentType } });
		},
		async get(key) {
			const object = await binding.get(key);
			if (!object) return null;
			const bytes = object.arrayBuffer ? new Uint8Array(await object.arrayBuffer()) : object.body ? new Uint8Array(await new Response(object.body).arrayBuffer()) : null;
			if (!bytes) return null;
			return {
				bytes,
				contentType: object.httpMetadata?.contentType ?? null
			};
		},
		delete(key) {
			return binding.delete(key);
		}
	};
}
function wrapDatabase(binding) {
	const statement = (sql, params) => {
		const prepared = binding.prepare(sql);
		return params.length > 0 ? prepared.bind(...params) : prepared;
	};
	return {
		async all(sql, params = []) {
			return (await statement(sql, params).all()).results ?? [];
		},
		async run(sql, params = []) {
			await statement(sql, params).run();
		}
	};
}
var storePromise = null;
/** The MEDIA bucket and DB database declared in cloudflare.config.ts. */
function openMediaStore() {
	storePromise ??= (async () => {
		const env = await readMediaBindings();
		if (!env?.MEDIA || !env.DB) throw new MediaBindingError();
		const store = createMediaStore(wrapBucket(env.MEDIA), wrapDatabase(env.DB));
		await store.ready;
		return store;
	})().catch((error) => {
		storePromise = null;
		throw error;
	});
	return storePromise;
}
//#endregion
export { MediaBindingError, openMediaStore };
