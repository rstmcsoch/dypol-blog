import { T as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-wjzIUxJ1.mjs";
import { t as ArticleEditor } from "./editor-Bi3JKGTR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-DorUKGm1.js
var import_jsx_runtime = require_jsx_runtime();
function NewPiece() {
	const data = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleEditor, {
		article: null,
		categories: data.categories,
		tags: data.tags,
		media: data.media
	});
}
//#endregion
export { NewPiece as component };
