import { o as __toESM } from "../_runtime.mjs";
import { T as require_jsx_runtime, et as require_react, w as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as adminUploadMedia, _ as errorText, f as Route$11, x as adminDeleteMedia } from "./router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-C21AoKTU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MediaDesk() {
	const data = Route$11.useLoaderData();
	const router = useRouter();
	const [error, setError] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-kicker",
			children: "Library"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "desk-title",
			children: "Media"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: "Images go in the existing dypol-blog-media bucket through the MEDIA binding. The file name, alt text, and size are recorded in D1. JPEG, PNG, WebP, and GIF, up to 1.5 MB."
		}),
		data.notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner banner--bad",
			role: "alert",
			children: data.notice
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner banner--bad",
			role: "alert",
			children: error
		}) : null,
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner",
			role: "status",
			children: message
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "stack",
			style: { marginTop: "1rem" },
			onSubmit: (event) => {
				event.preventDefault();
				const form = event.currentTarget;
				const file = form.elements.namedItem("file").files?.[0];
				const alt = String(new FormData(form).get("alt") ?? "");
				if (!file) return;
				setPending(true);
				setError(null);
				const reader = new FileReader();
				reader.onload = () => {
					adminUploadMedia({ data: {
						filename: file.name,
						mime: file.type,
						alt,
						dataBase64: String(reader.result ?? "")
					} }).then(async () => {
						setMessage("Uploaded.");
						form.reset();
						await router.invalidate();
					}).catch((caught) => setError(errorText(caught))).finally(() => setPending(false));
				};
				reader.readAsDataURL(file);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "File" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "file",
						type: "file",
						accept: "image/jpeg,image/png,image/webp,image/gif",
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Alt text" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { name: "alt" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					type: "submit",
					disabled: pending,
					children: pending ? "Uploading…" : "Upload"
				})
			]
		}),
		data.media.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: "The library is empty."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "media-grid",
			children: data.media.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "media-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: `/media/${item.id}`,
					alt: item.alt || ""
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.filename }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [Math.max(1, Math.round(item.bytes / 1024)), " KB"] }),
					confirmId === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Delete this file?" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => {
								adminDeleteMedia({ data: { id: item.id } }).then(async () => {
									setMessage("Deleted.");
									setConfirmId(null);
									await router.invalidate();
								}).catch((caught) => setError(errorText(caught)));
							},
							children: "Delete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn--ghost",
							onClick: () => setConfirmId(null),
							children: "Cancel"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn--ghost",
						onClick: () => setConfirmId(item.id),
						children: "Delete"
					})
				] })]
			}, item.id))
		})
	] });
}
//#endregion
export { MediaDesk as component };
