import { o as __toESM } from "../_runtime.mjs";
import { T as require_jsx_runtime, et as require_react, w as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as adminSaveTag, S as adminDeleteTag, T as adminSaveCategory, _ as errorText, u as Route$9, y as adminDeleteCategory } from "./router-wjzIUxJ1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topics-BRXoeZzS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TopicsDesk() {
	const data = Route$9.useLoaderData();
	const router = useRouter();
	const [error, setError] = (0, import_react.useState)(null);
	const [message, setMessage] = (0, import_react.useState)(null);
	async function run(action, success) {
		setError(null);
		setMessage(null);
		try {
			await action();
			setMessage(success);
			await router.invalidate();
		} catch (caught) {
			setError(errorText(caught));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-kicker",
			children: "Taxonomy"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "desk-title",
			children: "Topics and tags"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "desk-note",
			children: "A topic or tag that still belongs to a piece cannot be deleted."
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner banner--bad",
			role: "alert",
			children: error
		}) : null,
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "banner",
			role: "status",
			children: message
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "desk-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Topics" }),
				data.categories.map((category) => {
					const count = data.articles.filter((article) => article.categoryId === category.id).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "block-card",
						onSubmit: (event) => {
							event.preventDefault();
							const form = new FormData(event.currentTarget);
							run(() => adminSaveCategory({ data: {
								id: category.id,
								label: String(form.get("label") ?? ""),
								slug: String(form.get("slug") ?? ""),
								description: String(form.get("description") ?? "")
							} }), "Topic saved.");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Label" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "label",
									defaultValue: category.label,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "slug",
									defaultValue: category.slug
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									name: "description",
									defaultValue: category.description
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-actions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn",
									type: "submit",
									children: "Save"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "btn btn--ghost",
									type: "button",
									onClick: () => {
										if (count > 0) {
											setError("Move the pieces in this topic before deleting it.");
											return;
										}
										run(() => adminDeleteCategory({ data: { id: category.id } }), "Topic deleted.");
									},
									children: [
										"Delete (",
										count,
										" pieces)"
									]
								})]
							})
						]
					}, category.id);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "block-card",
					onSubmit: (event) => {
						event.preventDefault();
						const formEl = event.currentTarget;
						const form = new FormData(formEl);
						run(async () => {
							await adminSaveCategory({ data: {
								id: null,
								label: String(form.get("label") ?? ""),
								slug: String(form.get("slug") ?? ""),
								description: String(form.get("description") ?? "")
							} });
							formEl.reset();
						}, "Topic created.");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "New topic" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Label" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "label",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { name: "slug" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", { name: "description" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn",
							type: "submit",
							children: "Create topic"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "desk-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Tags" }),
				data.tags.map((tag) => {
					const count = data.articles.filter((article) => article.tagIds.includes(tag.id)).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "filters",
						onSubmit: (event) => {
							event.preventDefault();
							const form = new FormData(event.currentTarget);
							run(() => adminSaveTag({ data: {
								id: tag.id,
								label: String(form.get("label") ?? ""),
								slug: String(form.get("slug") ?? "")
							} }), "Tag saved.");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Label" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "label",
									defaultValue: tag.label,
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "slug",
									defaultValue: tag.slug
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn",
								type: "submit",
								children: "Save"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn btn--ghost",
								type: "button",
								onClick: () => {
									if (count > 0) {
										setError("Remove this tag from its pieces before deleting it.");
										return;
									}
									run(() => adminDeleteTag({ data: { id: tag.id } }), "Tag deleted.");
								},
								children: [
									"Delete (",
									count,
									")"
								]
							})
						]
					}, tag.id);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "filters",
					onSubmit: (event) => {
						event.preventDefault();
						const formEl = event.currentTarget;
						const form = new FormData(formEl);
						run(async () => {
							await adminSaveTag({ data: {
								id: null,
								label: String(form.get("label") ?? ""),
								slug: String(form.get("slug") ?? "")
							} });
							formEl.reset();
						}, "Tag created.");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "New tag" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "label",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Slug" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { name: "slug" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn",
							type: "submit",
							children: "Create tag"
						})
					]
				})
			]
		})
	] });
}
//#endregion
export { TopicsDesk as component };
