//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DP4XBgUS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/about",
			"/admin",
			"/login",
			"/robots.txt",
			"/sitemap.xml",
			"/articles/$slug",
			"/media/$id",
			"/preview/$id",
			"/topics/$slug",
			"/articles/",
			"/topics/"
		],
		preloads: [
			"/assets/index-DirjJegP.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/createServerFn-DsB1t4L_.js",
			"/assets/route-BjFfJI3R.js",
			"/assets/preload-helper-D-11W5Gu.js",
			"/assets/use-site-C6Jaeeij.js",
			"/assets/states-C0_EcyT8.js",
			"/assets/admin-api-FZDZ8L_P.js",
			"/assets/public-api-DchWWpIb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DirjJegP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CiIdSucy.js",
			"/assets/format-DU4KtnPM.js",
			"/assets/cover-plate-BCp0kJDW.js",
			"/assets/index-list-wTnkgpa1.js",
			"/assets/topic-grid-5kpSVrW1.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-C9DaRhY7.js", "/assets/_-CqVDIk53.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-3pJPhLoj.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: [
			"/admin/media",
			"/admin/settings",
			"/admin/topics",
			"/admin/",
			"/admin/articles/$id",
			"/admin/articles/new",
			"/admin/articles/"
		],
		preloads: ["/assets/admin-DABBp3Ke.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-Bs7jNgPv.js", "/assets/client-CM31wX-O.js"]
	},
	"/admin/media": {
		filePath: "/workspace/src/routes/admin/media.tsx",
		children: void 0,
		preloads: ["/assets/media-Ca43QNxW.js"]
	},
	"/admin/settings": {
		filePath: "/workspace/src/routes/admin/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-DEHQ2CQd.js"]
	},
	"/admin/topics": {
		filePath: "/workspace/src/routes/admin/topics.tsx",
		children: void 0,
		preloads: ["/assets/topics-BsFJk7XR.js"]
	},
	"/articles/$slug": {
		filePath: "/workspace/src/routes/articles/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-B82kOOwQ.js",
			"/assets/_slug-J8dT1Gy6.js",
			"/assets/article-view-BqVD2vBu.js"
		]
	},
	"/preview/$id": {
		filePath: "/workspace/src/routes/preview/$id.tsx",
		children: void 0,
		preloads: ["/assets/_id-Cho1i3Lk.js", "/assets/article-view-BqVD2vBu.js"]
	},
	"/topics/$slug": {
		filePath: "/workspace/src/routes/topics/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-CqVDIk53.js",
			"/assets/_slug-m-z6Lsmn.js",
			"/assets/index-list-wTnkgpa1.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin/index.tsx",
		children: void 0,
		preloads: ["/assets/admin-D7C8SM0c.js", "/assets/format-DU4KtnPM.js"]
	},
	"/articles/": {
		filePath: "/workspace/src/routes/articles/index.tsx",
		children: void 0,
		preloads: ["/assets/articles-D6gK_H6r.js", "/assets/index-list-wTnkgpa1.js"]
	},
	"/topics/": {
		filePath: "/workspace/src/routes/topics/index.tsx",
		children: void 0,
		preloads: ["/assets/topics-BucKf85c.js", "/assets/topic-grid-5kpSVrW1.js"]
	},
	"/admin/articles/$id": {
		filePath: "/workspace/src/routes/admin/articles/$id.tsx",
		children: void 0,
		preloads: ["/assets/_id-B3tzoFms.js", "/assets/editor-BIAVzr_h.js"]
	},
	"/admin/articles/new": {
		filePath: "/workspace/src/routes/admin/articles/new.tsx",
		children: void 0,
		preloads: ["/assets/new-CguceEsB.js", "/assets/editor-BIAVzr_h.js"]
	},
	"/admin/articles/": {
		filePath: "/workspace/src/routes/admin/articles/index.tsx",
		children: void 0,
		preloads: ["/assets/articles-D4kGsuR4.js", "/assets/format-DU4KtnPM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
