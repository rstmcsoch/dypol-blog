import { T as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./_ssr/router-wjzIUxJ1.mjs";
import { t as ArticleEditor } from "./_ssr/editor-Bi3JKGTR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-CEqyKH7G.js
var import_jsx_runtime = require_jsx_runtime();
function EditPiece() {
	const data = Route$1.useLoaderData();
	if (!data.article) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleEditor, {
		article: data.article,
		categories: data.categories,
		tags: data.tags,
		media: data.media
	});
}
//#endregion
export { EditPiece as component };
