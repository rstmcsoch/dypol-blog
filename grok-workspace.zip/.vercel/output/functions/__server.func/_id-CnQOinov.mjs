import { T as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { s as Route$5 } from "./_ssr/router-wjzIUxJ1.mjs";
import { t as ArticleView } from "./_ssr/article-view-CzJP606H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-CnQOinov.js
var import_jsx_runtime = require_jsx_runtime();
function PreviewPage() {
	const data = Route$5.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleView, {
		...data,
		site: data.site
	});
}
//#endregion
export { PreviewPage as component };
