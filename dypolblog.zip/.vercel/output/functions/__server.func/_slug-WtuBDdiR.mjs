import { f as NotFoundState } from "./_ssr/router-DSBBz0x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-WtuBDdiR.js
var SplitNotFoundComponent = NotFoundState;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
