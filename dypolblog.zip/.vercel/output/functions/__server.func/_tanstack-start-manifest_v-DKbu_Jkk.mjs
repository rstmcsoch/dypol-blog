//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DKbu_Jkk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/about",
			"/robots.txt",
			"/sitemap.xml",
			"/articles/$slug",
			"/topics/$slug",
			"/articles/",
			"/topics/"
		],
		preloads: [
			"/assets/index-COn1XTGi.js",
			"/assets/site-BbVuA4GS.js",
			"/assets/link-Cu8c3BKl.js",
			"/assets/not-found-i5RsCZif.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-COn1XTGi.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DYJTmq63.js",
			"/assets/cover-plate-mneU2ZS6.js",
			"/assets/format-DU4KtnPM.js",
			"/assets/index-list-C29dQHCd.js",
			"/assets/topic-grid-D7eXO6GP.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-CawIpcsc.js", "/assets/_-D5Lp3UFX.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CDw5jOZA.js"]
	},
	"/articles/$slug": {
		filePath: "/workspace/src/routes/articles/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-BPYW-w1C.js",
			"/assets/_slug-DqHjhFLu.js",
			"/assets/cover-plate-mneU2ZS6.js",
			"/assets/format-DU4KtnPM.js",
			"/assets/index-list-C29dQHCd.js"
		]
	},
	"/topics/$slug": {
		filePath: "/workspace/src/routes/topics/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-BuwRJ2bi.js",
			"/assets/index-list-C29dQHCd.js",
			"/assets/_slug-CawIpcsc.js"
		]
	},
	"/articles/": {
		filePath: "/workspace/src/routes/articles/index.tsx",
		children: void 0,
		preloads: ["/assets/articles-BNCNyVhn.js", "/assets/index-list-C29dQHCd.js"]
	},
	"/topics/": {
		filePath: "/workspace/src/routes/topics/index.tsx",
		children: void 0,
		preloads: ["/assets/topics-fJ1jN3xC.js", "/assets/topic-grid-D7eXO6GP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
