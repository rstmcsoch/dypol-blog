import { f as NotFoundState } from "./_ssr/router-DSBBz0x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-HSKArinX.js
var SplitComponent = NotFoundState;
//#endregion
export { SplitComponent as component };
