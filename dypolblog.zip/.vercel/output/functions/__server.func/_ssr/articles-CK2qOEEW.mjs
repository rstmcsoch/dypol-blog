import { t as site } from "./site-C7SWWYz3.mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$3 } from "./router-DSBBz0x_.mjs";
import { t as IndexList } from "./index-list-CUfvjvGx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articles-CK2qOEEW.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlesPage() {
	const { articles } = Route$3.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.indexKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: site.labels.indexTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: site.labels.indexLede
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, { articles })]
		})
	});
}
//#endregion
export { ArticlesPage as component };
