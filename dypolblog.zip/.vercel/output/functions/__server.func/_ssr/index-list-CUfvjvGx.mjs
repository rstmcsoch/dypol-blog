import { t as site } from "./site-C7SWWYz3.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as rankOf, o as getCategory, u as readingMinutes } from "./router-DSBBz0x_.mjs";
import { n as padIndex, t as formatDate } from "./format-BabHa5xU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/index-list-CUfvjvGx.js
var import_jsx_runtime = require_jsx_runtime();
function IndexList({ articles }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "index-list",
		children: articles.map((article) => {
			const category = getCategory(article.categoryId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/articles/$slug",
				params: { slug: article.slug },
				className: "index-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "index-row__num",
						children: padIndex(rankOf(article.slug))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "index-row__main",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "index-row__title",
							children: article.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "index-row__excerpt",
							children: article.excerpt
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "index-row__meta",
						children: [
							category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: category.label }) : null,
							article.publishedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate(article.publishedAt) }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								readingMinutes(article),
								" ",
								site.labels.minRead
							] })
						]
					})
				]
			}) }, article.id);
		})
	});
}
//#endregion
export { IndexList as t };
