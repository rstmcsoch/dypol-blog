import { i as __toESM } from "../_runtime.mjs";
import { t as site } from "./site-C7SWWYz3.mjs";
import { J as notFound, S as require_jsx_runtime, Y as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as Moon, t as Sun } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/states-Bhn6FOpf.js
var import_jsx_runtime = require_jsx_runtime();
function EmptyState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "state-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "state-panel__num",
				children: "00"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "state-panel__title",
				children: site.labels.emptyTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "state-panel__body",
				children: site.labels.emptyBody
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/articles",
				className: "btn btn--ghost",
				children: site.labels.emptyAction
			})
		]
	});
}
function NotFoundState() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "state-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.notFoundKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "state-panel__title",
						children: site.labels.notFoundTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "state-panel__body",
						children: site.labels.notFoundBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "btn",
						children: site.labels.backHome
					})
				]
			})
		})
	});
}
function PagePending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		"aria-busy": "true",
		"aria-live": "polite",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: site.labels.loading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton skeleton--title" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton skeleton--short" })
			]
		})
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/queries-B_bzqJNp.js
var articles = [
	{
		id: "art-quiet-architecture",
		slug: "quiet-architecture-of-a-page",
		title: "The quiet architecture of a published page",
		excerpt: "A page worth reading is mostly structure: a title, a time, a place in the index, and a body that does not fight the measure.",
		status: "published",
		publishedAt: "2026-10-04T08:00:00.000Z",
		updatedAt: "2026-10-04T08:00:00.000Z",
		categoryId: "systems",
		tagIds: ["structure", "layout"],
		motif: "corner",
		featured: true,
		blocks: [
			{
				type: "paragraph",
				text: "Most of what makes a journal feel finished is invisible. The reader meets a title, a date, and a column of type. Under that, the page has already decided what a piece is allowed to be."
			},
			{
				type: "heading",
				level: 2,
				text: "One shape, used everywhere"
			},
			{
				type: "paragraph",
				text: "A piece needs a stable identity: a slug that does not change, a status that is explicit, a category, and a body made of known blocks. If the public page, the editor, and an automated submission all speak that same shape, nothing has to be translated on the way out."
			},
			{
				type: "list",
				items: [
					"Draft means it is not on the public index.",
					"Published means a reader can open it.",
					"Unpublished means it was pulled, and it stays out of the index."
				]
			},
			{
				type: "heading",
				level: 2,
				text: "What the page refuses"
			},
			{
				type: "paragraph",
				text: "The body is not a bucket of unmarked HTML. Paragraphs, headings, lists, quotations, and code are separate. That keeps the reading column predictable and keeps a bad paste from becoming the layout."
			},
			{
				type: "quote",
				text: "If a field can be guessed, an automated writer will guess it wrong. Name it."
			},
			{
				type: "paragraph",
				text: "The sample essays in this journal exist to show that structure. They are not a history of the lab. They are a demonstration of the page."
			}
		]
	},
	{
		id: "art-hard-edge",
		slug: "hard-edge-returns",
		title: "Borders, type, and the return of the hard edge",
		excerpt: "A hard edge is not decoration. It is how a publication tells you where one thing ends and the next begins.",
		status: "published",
		publishedAt: "2026-10-01T08:00:00.000Z",
		updatedAt: "2026-10-01T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["type", "layout"],
		motif: "split",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "Soft cards and blurred shadows make everything feel like the same surface. A journal needs the opposite: a rule you can see, a shadow that is honestly offset, a corner that does not pretend to be a pebble."
			},
			{
				type: "heading",
				level: 2,
				text: "Black, white, then one color"
			},
			{
				type: "paragraph",
				text: "The day page is white. The night page is black. Those two carry the structure. A single blue is allowed on a stamp, a band, or a plate — and only there does the grain appear. The type stays clean."
			},
			{
				type: "paragraph",
				text: "Headlines can be loud. Body text cannot. The column stays narrow enough to read, and the type size does not jump just because the screen is wide."
			}
		]
	},
	{
		id: "art-machine",
		slug: "what-a-machine-should-send",
		title: "What a machine should send when it publishes",
		excerpt: "An automated writer should submit a document, not pretend to click through a form. The document has to be the same one a person would save.",
		status: "published",
		publishedAt: "2026-09-26T08:00:00.000Z",
		updatedAt: "2026-09-26T08:00:00.000Z",
		categoryId: "systems",
		tagIds: ["workflow", "structure"],
		motif: "band",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "If a publishing flow depends on a particular model, a particular vendor, or a screen full of buttons, it will break the moment any of those change. The durable part is the payload."
			},
			{
				type: "heading",
				level: 2,
				text: "A payload, not a performance"
			},
			{
				type: "paragraph",
				text: "The useful submission names its fields, validates them, and returns a clear success or a list of errors. It can be retried. It does not invent a second article format for machines."
			},
			{
				type: "code",
				language: "json",
				code: "{\n  \"slug\": \"working-title\",\n  \"status\": \"draft\",\n  \"title\": \"Working title\",\n  \"categoryId\": \"systems\"\n}"
			},
			{
				type: "paragraph",
				text: "A person using an editor later should produce this same object. The public page should render this same object. The agent is replaceable. The article is not."
			}
		]
	},
	{
		id: "art-reading-width",
		slug: "reading-width",
		title: "Reading width is a product decision",
		excerpt: "A line that runs the full width of a monitor is not generous. It is harder to read. The measure should stay put.",
		status: "published",
		publishedAt: "2026-09-20T08:00:00.000Z",
		updatedAt: "2026-09-20T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["type", "layout"],
		motif: "edge",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "On a phone, the danger is type that is too big for the screen and margins that disappear. On a desktop, the danger is a paragraph that stretches until the eye loses the next line."
			},
			{
				type: "paragraph",
				text: "A reading column around sixty-six characters solves the second problem without making the first one worse. Headlines can be wider. The body should not copy them."
			},
			{
				type: "heading",
				level: 2,
				text: "Metadata stays out of the way"
			},
			{
				type: "paragraph",
				text: "Date, topic, and length belong near the title, in a smaller voice. They should not become a second article. If they wrap on a narrow screen, they wrap. They do not overflow."
			}
		]
	},
	{
		id: "art-index",
		slug: "an-index-not-a-feed",
		title: "An index, not a feed",
		excerpt: "A journal can show what it has without pretending the list is infinite. Numbers, rules, and titles are enough.",
		status: "published",
		publishedAt: "2026-09-14T08:00:00.000Z",
		updatedAt: "2026-09-14T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["index", "layout"],
		motif: "stack",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "A feed asks you to keep scrolling. An index tells you where you are. For a small publication, the index is the more honest object: a numbered list, a topic, a date, a title you can scan."
			},
			{
				type: "paragraph",
				text: "The homepage can still lead with one piece. The rest of the journal does not need to become a grid of identical cards. A rule between rows is a clearer invitation."
			},
			{
				type: "list",
				ordered: true,
				items: [
					"Put the newest piece where the eye lands first.",
					"Give the next few a shared band, not a new visual system.",
					"Let the remainder be a list."
				]
			}
		]
	},
	{
		id: "art-three-states",
		slug: "three-states",
		title: "Draft, published, withdrawn",
		excerpt: "A piece should not be public because somebody forgot a checkbox. The state is part of the article, and the index trusts it.",
		status: "published",
		publishedAt: "2026-09-08T08:00:00.000Z",
		updatedAt: "2026-09-08T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["workflow", "structure"],
		motif: "stamp",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "Three states are enough until a newsroom actually needs more. Draft: still being written. Published: on the site. Unpublished: kept, but not listed and not readable at its old address."
			},
			{
				type: "paragraph",
				text: "The public site never infers this from a missing date or a hidden flag buried in a template. Queries ask for published pieces and ignore the rest. A topic with only drafts looks empty on purpose."
			},
			{
				type: "quote",
				text: "Empty is a real state. It should look like the rest of the journal, not like a missing page."
			}
		]
	},
	{
		id: "art-frame",
		slug: "the-frame-around-a-picture",
		title: "The frame around a picture",
		excerpt: "Media should sit in a frame that already has a size. The page must not jump when the file arrives, and the picture must not stretch.",
		status: "published",
		publishedAt: "2026-09-02T08:00:00.000Z",
		updatedAt: "2026-09-02T08:00:00.000Z",
		categoryId: "design",
		tagIds: ["media", "layout"],
		motif: "corner",
		featured: false,
		blocks: [
			{
				type: "paragraph",
				text: "A cover is a promise about the piece, not a second layout. It keeps a fixed ratio, it has a description if it is a real image, and it loads after the title when it is not the first thing on the screen."
			},
			{
				type: "paragraph",
				text: "Until a piece has a picture, the frame can still be a plate: a number, a topic, a block of color. The plate is the same component the photograph will replace. The page does not grow a new hole."
			},
			{
				type: "heading",
				level: 2,
				text: "Grain stays on the color"
			},
			{
				type: "paragraph",
				text: "Noise on white type makes a page look dirty. Noise on a blue field looks like print. The frame uses the second one and leaves the headline alone."
			}
		]
	},
	{
		id: "art-notes-draft",
		slug: "desk-notes",
		title: "Desk notes",
		excerpt: "A draft that should not appear on the public index.",
		status: "draft",
		publishedAt: null,
		updatedAt: "2026-10-05T08:00:00.000Z",
		categoryId: "notes",
		tagIds: ["workflow"],
		motif: "edge",
		featured: false,
		blocks: [{
			type: "paragraph",
			text: "This draft exists so the public queries have something to exclude. It is not a published essay."
		}]
	},
	{
		id: "art-withdrawn",
		slug: "withdrawn-note",
		title: "A note that was withdrawn",
		excerpt: "An unpublished piece. It stays in the record and off the site.",
		status: "unpublished",
		publishedAt: "2026-08-01T08:00:00.000Z",
		updatedAt: "2026-08-20T08:00:00.000Z",
		categoryId: "publishing",
		tagIds: ["workflow"],
		motif: "band",
		featured: false,
		blocks: [{
			type: "paragraph",
			text: "This piece was withdrawn. The public index should not list it, and its address should not resolve."
		}]
	}
];
var categories = [
	{
		id: "systems",
		slug: "systems",
		label: "Systems",
		description: "How a publication is structured, stored, and handed from one step to the next."
	},
	{
		id: "design",
		slug: "design",
		label: "Design",
		description: "Type, edges, images, and the decisions that keep a long page readable."
	},
	{
		id: "publishing",
		slug: "publishing",
		label: "Publishing",
		description: "How a piece moves from a draft to something a reader can find."
	},
	{
		id: "notes",
		slug: "notes",
		label: "Notes",
		description: "Short filings. This topic is empty until something here is published."
	}
];
var tags = [
	{
		id: "structure",
		slug: "structure",
		label: "Structure"
	},
	{
		id: "type",
		slug: "type",
		label: "Type"
	},
	{
		id: "layout",
		slug: "layout",
		label: "Layout"
	},
	{
		id: "media",
		slug: "media",
		label: "Media"
	},
	{
		id: "workflow",
		slug: "workflow",
		label: "Workflow"
	},
	{
		id: "index",
		slug: "index",
		label: "Index"
	}
];
function byNewest(a, b) {
	const aTime = a.publishedAt ? Date.parse(a.publishedAt) : 0;
	return (b.publishedAt ? Date.parse(b.publishedAt) : 0) - aTime;
}
function listPublished() {
	return articles.filter((article) => article.status === "published" && article.publishedAt).sort(byNewest);
}
function getPublishedBySlug(slug) {
	return listPublished().find((article) => article.slug === slug);
}
function rankOf(slug) {
	const index = listPublished().findIndex((article) => article.slug === slug);
	return index === -1 ? 0 : index + 1;
}
function listCategories() {
	return categories;
}
function getCategory(idOrSlug) {
	return categories.find((category) => category.id === idOrSlug || category.slug === idOrSlug);
}
function listPublishedByCategory(slug) {
	const category = getCategory(slug);
	if (!category) return [];
	return listPublished().filter((article) => article.categoryId === category.id);
}
function publishedCount(categoryId) {
	return listPublished().filter((article) => article.categoryId === categoryId).length;
}
function getTag(id) {
	return tags.find((tag) => tag.id === id || tag.slug === id);
}
function tagsFor(article) {
	return article.tagIds.map((id) => getTag(id)).filter((tag) => Boolean(tag));
}
function featuredArticle() {
	const published = listPublished();
	return published.find((article) => article.featured) ?? published[0];
}
function relatedArticles(article, limit = 3) {
	const same = listPublished().filter((item) => item.categoryId === article.categoryId && item.id !== article.id);
	if (same.length >= limit) return same.slice(0, limit);
	const rest = listPublished().filter((item) => item.id !== article.id && !same.some((picked) => picked.id === item.id));
	return [...same, ...rest].slice(0, limit);
}
function neighbors(article) {
	const published = listPublished();
	const index = published.findIndex((item) => item.id === article.id);
	if (index === -1) return {};
	return {
		newer: published[index - 1],
		older: published[index + 1]
	};
}
function trendingArticles() {
	if (!site.trending.enabled) return [];
	return site.trending.slugs.map((slug) => getPublishedBySlug(slug)).filter((article) => Boolean(article));
}
function readingMinutes(article) {
	const words = blockText(article.blocks).trim().split(/\s+/).filter(Boolean).length;
	return Math.max(1, Math.round(words / 220));
}
function blockText(blocks) {
	return blocks.map((block) => {
		if (block.type === "list") return block.items.join(" ");
		if (block.type === "code") return block.code;
		return block.text;
	}).join(" ");
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DSBBz0x_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "error-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "state-panel",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "state-panel__title",
					children: site.labels.errorTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: errorMessage(error) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn",
					href: "/",
					children: site.labels.errorHome
				})
			]
		})
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function NavLink({ href, className, children }) {
	const activeProps = { className: "is-active" };
	if (href === "/") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className,
		activeOptions: { exact: true },
		activeProps,
		children
	});
	if (href === "/articles") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/articles",
		className,
		activeOptions: { exact: false },
		activeProps,
		children
	});
	if (href === "/topics") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/topics",
		className,
		activeOptions: { exact: false },
		activeProps,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/about",
		className,
		activeProps,
		children
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container footer-grid",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "footer-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "footer-mark",
						children: "DYPOL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "footer-note",
						children: site.description
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "footer-nav",
					"aria-label": site.labels.footerNav,
					children: site.nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						href: item.href,
						className: "footer-link",
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "footer-sign",
					children: site.footer.note
				})
			]
		})
	});
}
var THEME_KEY = "dypol-theme";
var themeBootScript = `(function(){try{var s=localStorage.getItem("${THEME_KEY}");var t=s==="light"||s==="dark"?s:(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");document.documentElement.setAttribute("data-theme",t);}catch(e){document.documentElement.setAttribute("data-theme","light");}})();`;
function readTheme() {
	const set = document.documentElement.dataset.theme;
	if (set === "light" || set === "dark") return set;
	return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function applyTheme(next, persist) {
	document.documentElement.dataset.theme = next;
	if (!persist) return;
	try {
		localStorage.setItem(THEME_KEY, next);
	} catch {}
}
function ThemeToggle() {
	const [theme, setTheme] = (0, import_react.useState)(null);
	(0, import_react.useLayoutEffect)(() => {
		setTheme(readTheme());
	}, []);
	function choose(next) {
		applyTheme(next, true);
		setTheme(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "theme-switch",
		role: "group",
		"aria-label": site.labels.themeGroup,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "theme-switch__btn",
			"data-value": "light",
			"aria-label": site.labels.dayTheme,
			"aria-pressed": theme === null ? void 0 : theme === "light",
			onClick: () => choose("light"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
					"aria-hidden": "true",
					strokeWidth: 2.25
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__label",
					children: site.labels.day
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__mark",
					"aria-hidden": "true"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "theme-switch__btn",
			"data-value": "dark",
			"aria-label": site.labels.nightTheme,
			"aria-pressed": theme === null ? void 0 : theme === "dark",
			onClick: () => choose("dark"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
					"aria-hidden": "true",
					strokeWidth: 2.25
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__label",
					children: site.labels.night
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "theme-switch__mark",
					"aria-hidden": "true"
				})
			]
		})]
	});
}
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "site-header",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container bar",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavLink, {
					href: "/",
					className: "wordmark",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "wordmark__name",
						children: "DYPOL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "wordmark__stamp",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grain-layer",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Blog" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					id: "site-nav",
					className: open ? "site-nav is-open" : "site-nav",
					"aria-label": site.labels.primaryNav,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "site-nav__inner",
						children: site.nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
							href: item.href,
							className: "nav-link",
							children: item.label
						}, item.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bar-tools",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "menu-btn",
						"aria-expanded": open,
						"aria-controls": "site-nav",
						onClick: () => setOpen((value) => !value),
						children: open ? site.labels.close : site.labels.menu
					})]
				})
			]
		})
	});
}
/** Re-apply the boot script's choice after hydration, in case the attribute was reset. */
function ThemeSync() {
	(0, import_react.useLayoutEffect)(() => {
		let stored = null;
		try {
			stored = localStorage.getItem(THEME_KEY);
		} catch {
			stored = null;
		}
		if (stored === "light" || stored === "dark") {
			applyTheme(stored, false);
			return;
		}
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		const sync = () => {
			let stored = null;
			try {
				stored = localStorage.getItem(THEME_KEY);
			} catch {
				stored = null;
			}
			if (stored === "light" || stored === "dark") return;
			applyTheme(media.matches ? "dark" : "light", false);
		};
		sync();
		media.addEventListener("change", sync);
		return () => media.removeEventListener("change", sync);
	}, []);
	return null;
}
function TrendingBar() {
	const items = trendingArticles();
	if (!site.trending.enabled || items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "trend",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container trend__row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "trend__label",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grain-layer",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: site.trending.label })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "trend__list",
				children: items.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/articles/$slug",
					params: { slug: article.slug },
					className: "trend__link",
					children: article.title
				}) }, article.id))
			})]
		})
	});
}
var styles_default = "/assets/styles-BXycuaGJ.css";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: site.title },
			{
				name: "description",
				content: site.description
			},
			{
				name: "theme-color",
				content: "#111111"
			},
			{
				name: "robots",
				content: "index, follow"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootLayout,
	notFoundComponent: NotFoundState
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: themeBootScript } }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function RootLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "skip",
				href: "#content",
				children: site.labels.skip
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSync, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var $$splitComponentImporter$6 = () => import("./routes-Dm6lzD-1.mjs");
var Route$8 = createFileRoute("/")({
	loader: () => {
		const published = listPublished();
		const lead = featuredArticle();
		const rest = published.filter((article) => article.id !== lead?.id);
		return {
			lead,
			band: rest.slice(0, 3),
			index: rest.slice(3)
		};
	},
	head: () => ({
		meta: [{ title: site.title }, {
			name: "description",
			content: site.description
		}],
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("../_-HSKArinX.mjs");
var $$splitNotFoundComponentImporter$2 = () => import("../_-CML-_B7M.mjs");
var Route$7 = createFileRoute("/$")({
	loader: () => {
		throw notFound();
	},
	head: () => ({ meta: [{ title: `${site.labels.notFoundKicker} — ${site.name}` }, {
		name: "robots",
		content: "noindex"
	}] }),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$2, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./about-Dv4AlNkX.mjs");
var Route$6 = createFileRoute("/about")({
	head: () => ({
		meta: [{ title: `${site.labels.aboutTitle} — ${site.name}` }, {
			name: "description",
			content: site.about.paragraphs[0]
		}],
		links: [{
			rel: "canonical",
			href: "/about"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var Route$5 = createFileRoute("/robots.txt")({ server: { handlers: { GET: ({ request }) => {
	const body = `User-agent: *\nAllow: /\nSitemap: ${new URL(request.url).origin}/sitemap.xml\n`;
	return new Response(body, { headers: { "content-type": "text/plain; charset=utf-8" } });
} } } });
var Route$4 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: ({ request }) => {
	const origin = new URL(request.url).origin;
	const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${[
		"/",
		"/articles",
		"/topics",
		"/about",
		...listPublished().map((article) => `/articles/${article.slug}`),
		...listCategories().map((category) => `/topics/${category.slug}`)
	].map((path) => `  <url><loc>${origin}${path}</loc></url>`).join("\n")}
</urlset>
`;
	return new Response(body, { headers: { "content-type": "application/xml; charset=utf-8" } });
} } } });
var $$splitComponentImporter$3 = () => import("./articles-CK2qOEEW.mjs");
var Route$3 = createFileRoute("/articles/")({
	loader: () => ({ articles: listPublished() }),
	head: () => ({
		meta: [{ title: `${site.labels.indexTitle} — ${site.name}` }, {
			name: "description",
			content: site.labels.indexLede
		}],
		links: [{
			rel: "canonical",
			href: "/articles"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_slug-Dz3ateN3.mjs");
var $$splitNotFoundComponentImporter$1 = () => import("../_slug-WtuBDdiR.mjs");
var Route$2 = createFileRoute("/articles/$slug")({
	loader: ({ params }) => {
		const article = getPublishedBySlug(params.slug);
		if (!article) throw notFound();
		return {
			article,
			category: getCategory(article.categoryId),
			tags: tagsFor(article),
			related: relatedArticles(article, 3),
			neighbors: neighbors(article),
			rank: rankOf(article.slug)
		};
	},
	head: ({ loaderData }) => {
		if (!loaderData) return {};
		const { article } = loaderData;
		const title = article.seoTitle ?? `${article.title} — ${site.name}`;
		const description = article.seoDescription ?? article.excerpt;
		const jsonLd = {
			"@context": "https://schema.org",
			"@type": "BlogPosting",
			headline: article.title,
			description,
			datePublished: article.publishedAt,
			dateModified: article.updatedAt,
			articleSection: loaderData.category?.label,
			publisher: {
				"@type": "Organization",
				name: site.publisher
			}
		};
		return {
			meta: [{ title }, {
				name: "description",
				content: description
			}],
			links: [{
				rel: "canonical",
				href: `/articles/${article.slug}`
			}],
			scripts: [{
				type: "application/ld+json",
				children: JSON.stringify(jsonLd)
			}]
		};
	},
	pendingComponent: PagePending,
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$1, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./topics-pKFrCENS.mjs");
var Route$1 = createFileRoute("/topics/")({
	head: () => ({
		meta: [{ title: `${site.labels.topicsTitle} — ${site.name}` }, {
			name: "description",
			content: site.labels.topicsLede
		}],
		links: [{
			rel: "canonical",
			href: "/topics"
		}]
	}),
	pendingComponent: PagePending,
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_slug-C9aewM9i.mjs");
var $$splitNotFoundComponentImporter = () => import("../_slug-D-R1KCmT.mjs");
var Route = createFileRoute("/topics/$slug")({
	loader: ({ params }) => {
		const category = getCategory(params.slug);
		if (!category) throw notFound();
		return {
			category,
			articles: listPublishedByCategory(params.slug)
		};
	},
	head: ({ loaderData }) => {
		if (!loaderData) return {};
		return {
			meta: [{ title: `${loaderData.category.label} — ${site.name}` }, {
				name: "description",
				content: loaderData.category.description
			}],
			links: [{
				rel: "canonical",
				href: `/topics/${loaderData.category.slug}`
			}]
		};
	},
	pendingComponent: PagePending,
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$9
});
var SplatRoute = Route$7.update({
	id: "/$",
	path: "/$",
	getParentRoute: () => Route$9
});
var AboutRoute = Route$6.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$9
});
var RobotsDottxtRoute = Route$5.update({
	id: "/robots.txt",
	path: "/robots.txt",
	getParentRoute: () => Route$9
});
var SitemapDotxmlRoute = Route$4.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$9
});
var ArticlesIndexRoute = Route$3.update({
	id: "/articles/",
	path: "/articles/",
	getParentRoute: () => Route$9
});
var ArticlesSlugRoute = Route$2.update({
	id: "/articles/$slug",
	path: "/articles/$slug",
	getParentRoute: () => Route$9
});
var TopicsIndexRoute = Route$1.update({
	id: "/topics/",
	path: "/topics/",
	getParentRoute: () => Route$9
});
var rootRouteChildren = {
	IndexRoute,
	SplatRoute,
	AboutRoute,
	RobotsDottxtRoute,
	SitemapDotxmlRoute,
	ArticlesSlugRoute,
	TopicsSlugRoute: Route.update({
		id: "/topics/$slug",
		path: "/topics/$slug",
		getParentRoute: () => Route$9
	}),
	ArticlesIndexRoute,
	TopicsIndexRoute
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$8 as a, publishedCount as c, EmptyState as d, NotFoundState as f, Route$3 as i, rankOf as l, Route as n, getCategory as o, Route$2 as r, listCategories as s, router_exports as t, readingMinutes as u };
