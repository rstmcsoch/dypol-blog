import { t as site } from "./site-C7SWWYz3.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$8, l as rankOf, o as getCategory, u as readingMinutes } from "./router-DSBBz0x_.mjs";
import { n as padIndex, t as formatDate } from "./format-BabHa5xU.mjs";
import { t as IndexList } from "./index-list-CUfvjvGx.mjs";
import { t as CoverPlate } from "./cover-plate-7EjIFUWy.mjs";
import { t as TopicGrid } from "./topic-grid-BZpC9HGd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dm6lzD-1.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { lead, band, index } = Route$8.useLoaderData();
	if (!lead) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "page-title",
				children: site.name
			})
		})
	});
	const category = getCategory(lead.categoryId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "lead-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container lead-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lead-copy",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "kicker",
							children: [site.labels.featured, category ? ` · ${category.label}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/articles/$slug",
								params: { slug: lead.slug },
								children: lead.title
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lede",
							children: lead.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "meta",
							children: [lead.publishedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate(lead.publishedAt) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								readingMinutes(lead),
								" ",
								site.labels.minRead
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/articles/$slug",
							params: { slug: lead.slug },
							className: "btn",
							children: site.labels.read
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/articles/$slug",
					params: { slug: lead.slug },
					className: "plate-link",
					"aria-label": lead.title,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverPlate, {
						motif: lead.motif,
						index: padIndex(rankOf(lead.slug)),
						category: category?.label ?? ""
					})
				})]
			})
		}),
		band.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "band",
			"aria-labelledby": "also-filed",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grain-layer",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container band-inner",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "also-filed",
					className: "band-head",
					children: site.labels.also
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "band-grid",
					children: band.map((article) => {
						const topic = getCategory(article.categoryId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/articles/$slug",
							params: { slug: article.slug },
							className: "band-link",
							children: [topic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "band-link__cat",
								children: topic.label
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "band-link__title",
								children: article.title
							})]
						}) }, article.id);
					})
				})]
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			"aria-labelledby": "latest",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "latest",
						children: site.labels.latest
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/articles",
						className: "text-link",
						children: site.labels.fullIndex
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, { articles: index })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section section--flush",
			"aria-labelledby": "topics",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-head",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "topics",
						children: site.labels.topics
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicGrid, {})]
			})
		})
	] });
}
//#endregion
export { Home as component };
