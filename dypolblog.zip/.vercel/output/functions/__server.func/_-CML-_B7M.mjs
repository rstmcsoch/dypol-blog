import { f as NotFoundState } from "./_ssr/router-DSBBz0x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-CML-_B7M.js
var SplitNotFoundComponent = NotFoundState;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
