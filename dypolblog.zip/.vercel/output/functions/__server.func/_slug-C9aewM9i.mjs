import { t as site } from "./_ssr/site-C7SWWYz3.mjs";
import { S as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { d as EmptyState, n as Route } from "./_ssr/router-DSBBz0x_.mjs";
import { t as IndexList } from "./_ssr/index-list-CUfvjvGx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-C9aewM9i.js
var import_jsx_runtime = require_jsx_runtime();
function TopicPage() {
	const { category, articles } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "page-header",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: site.labels.topicsKicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "page-title",
						children: category.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: category.description
					})
				]
			}), articles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, { articles }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {})]
		})
	});
}
//#endregion
export { TopicPage as component };
