import { f as NotFoundState } from "./_ssr/router-DSBBz0x_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-D-R1KCmT.js
var SplitNotFoundComponent = NotFoundState;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
