import { t as site } from "./_ssr/site-C7SWWYz3.mjs";
import { S as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$2, u as readingMinutes } from "./_ssr/router-DSBBz0x_.mjs";
import { n as padIndex, t as formatDate } from "./_ssr/format-BabHa5xU.mjs";
import { t as IndexList } from "./_ssr/index-list-CUfvjvGx.mjs";
import { t as CoverPlate } from "./_ssr/cover-plate-7EjIFUWy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-Dz3ateN3.js
var import_jsx_runtime = require_jsx_runtime();
function ArticleBody({ blocks }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "article-body",
		children: blocks.map((block, index) => {
			const key = `${block.type}-${index}`;
			if (block.type === "paragraph") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: block.text }, key);
			if (block.type === "heading" && block.level === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: block.text }, key);
			if (block.type === "heading") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: block.text }, key);
			if (block.type === "list") {
				const ListTag = block.ordered ? "ol" : "ul";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTag, { children: block.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item)) }, key);
			}
			if (block.type === "quote") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: block.text }), block.attribution ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", { children: block.attribution }) : null] }, key);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.code }) }, key);
		})
	});
}
function ArticlePage() {
	const { article, category, tags, related, neighbors: side, rank } = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "article",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "article-top",
					children: [
						category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "article-kicker",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/topics/$slug",
								params: { slug: category.slug },
								children: category.label
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "article-title",
							children: article.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lede",
							children: article.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "meta",
							children: [article.publishedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDate(article.publishedAt) }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								readingMinutes(article),
								" ",
								site.labels.minRead
							] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "article-plate",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverPlate, {
						motif: article.motif,
						index: padIndex(rank),
						category: category?.label ?? ""
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "article-layout",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleBody, { blocks: article.blocks }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "article-aside",
						children: tags.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "tag-list",
							"aria-label": "Tags",
							children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tag.label }, tag.id))
						}) : null
					})]
				}),
				(side.newer || side.older) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "neighbor-list",
					"aria-label": site.labels.neighbors,
					children: [side.newer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/articles/$slug",
						params: { slug: side.newer.slug },
						className: "neighbor",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: site.labels.newer }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: side.newer.title })]
					}) : null, side.older ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/articles/$slug",
						params: { slug: side.older.slug },
						className: "neighbor",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: site.labels.older }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: side.older.title })]
					}) : null]
				}),
				related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "section",
					"aria-labelledby": "continue",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "continue",
						children: site.labels.related
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexList, { articles: related })]
				}) : null
			]
		})
	});
}
//#endregion
export { ArticlePage as component };
